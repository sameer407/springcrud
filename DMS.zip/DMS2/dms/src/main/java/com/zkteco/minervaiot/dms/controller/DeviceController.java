package com.zkteco.minervaiot.dms.controller;

import java.util.List;

import com.zkteco.minervaiot.dms.dto.DeviceDeleteDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.zkteco.minervaiot.dms.dto.DeviceDTO;
import com.zkteco.minervaiot.dms.service.DeviceService;
import com.zkteco.minervaiot.dms.util.Result;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/v2.0")
@Api(tags = "Device", description = "This is the Device related API's.")
public class DeviceController {

	@Autowired
	DeviceService deviceService;

	/* This API is used to generate secret number */

	@ApiOperation(value = "Generate Secret Number", httpMethod = "POST", response = Result.class)
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Successfully Generated Secret Number"),
			@ApiResponse(code = 400, message = "Invalid input format."), @ApiResponse(code = 401, message = "Unauthorized access.")})
	@PostMapping("/devices/{sn}/secretNo")
	public ResponseEntity<Result> generateSecretNumbe(@PathVariable("sn") String sn) {
		return new ResponseEntity<>(deviceService.saveDeviceSecretNo(sn), HttpStatus.OK);
	}

	@ApiOperation(value = "Get Secret Number", httpMethod = "GET", response = Result.class)
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success."), @ApiResponse(code = 400, message = "Invalid input format."),
			@ApiResponse(code = 401, message = "Unauthorized access.")})
	@GetMapping("/devices/{sn}/secretNo")
	public ResponseEntity<Result> getSecretNumbe(@PathVariable("sn") String sn) {
		return new ResponseEntity<>(deviceService.getDeviceSecretNo(sn), HttpStatus.OK);
	}

	/* This API is used to create Device */

	// @ApiOperation(value = "Add Device", httpMethod = "POST", response =
	// Result.class)
	// @ApiResponses(value = {@ApiResponse(code = 200, message = "Successfully
	// Created Device"),
	// @ApiResponse(code = 400, message = "Invalid input format."),
	// @ApiResponse(code = 401, message = "Unauthorized access.")})
	// @PostMapping("/devices")
	// public ResponseEntity<Result> createDevice(@RequestBody DeviceDTO
	// deviceDTO) {
	// return new ResponseEntity<>(deviceService.createDevices(deviceDTO),
	// HttpStatus.OK);
	// }

	/* This API is used to update Device */

	@ApiOperation(value = "Update Device", httpMethod = "PUT", response = Result.class)
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Successfully Updated Device"),
			@ApiResponse(code = 400, message = "Invalid input format."), @ApiResponse(code = 401, message = "Unauthorized access.")})
	@PutMapping("/devices/{sn}")
	public ResponseEntity<Result> updateDevice(@PathVariable String sn, @RequestBody DeviceDTO deviceDTO) {
		return new ResponseEntity<>(deviceService.updateDevices(sn, deviceDTO), HttpStatus.OK);
	}

	/* This API is used to get Device by Filter */

	@ApiOperation(value = "Device List", httpMethod = "GET", response = Result.class)
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success."), @ApiResponse(code = 400, message = "Invalid input format."),
			@ApiResponse(code = 401, message = "Unauthorized access.")})
	@GetMapping("/devices")
	public ResponseEntity<Result> deviceSearch(@RequestParam(required = false) int pageNumber,
			@RequestParam(required = false) int pageSize, @RequestParam(required = false, defaultValue = "") String deviceSn,
			@RequestParam(required = false, defaultValue = "") String mac,
			@RequestParam(required = false, defaultValue = "") String productCode,
			@RequestParam(required = false, defaultValue = "") String deviceAlias) {
		return new ResponseEntity<>(deviceService.findByfilter(pageNumber, pageSize, deviceSn, mac, productCode, deviceAlias),
				HttpStatus.OK);

	}

	/* This API is used to create or update multiple device */

	@ApiOperation(value = "Add Device List", httpMethod = "POST", response = Result.class)
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Successfully Created Device"),
			@ApiResponse(code = 400, message = "Invalid input format."), @ApiResponse(code = 401, message = "Unauthorized access.")})
	@PostMapping("/devices")
	public ResponseEntity<Result> createDevice(@RequestBody List<DeviceDTO> deviceDTO) {
		return new ResponseEntity<>(deviceService.addOrUpdateDevice(deviceDTO), HttpStatus.OK);
	}


	/* This API is Get whether the current device is under the company */

	@ApiOperation(value = "Get Device Bind Company", httpMethod = "GET", response = Result.class)
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success."), @ApiResponse(code = 400, message = "Invalid input format."),
			@ApiResponse(code = 401, message = "Unauthorized access.")})
	@GetMapping("/devices/{sn}/bindCompany")
	public ResponseEntity<Result> getDeviceBindCompany(@PathVariable("sn") String sn){
		return new ResponseEntity<>(deviceService.getDeviceBindCompany(sn), HttpStatus.OK);
	}

	/* This api is used to delete devices under the company */

	@ApiOperation(value = "Delete Device", httpMethod = "DELETE", response = Result.class)
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Successfully Delete Device"),
			@ApiResponse(code = 400, message = "Invalid input format."), @ApiResponse(code = 401, message = "Unauthorized access.")})
	@DeleteMapping("/devices/{sn}")
	public ResponseEntity<Result> deleteDevice(@PathVariable String sn,@RequestBody DeviceDeleteDTO deviceDeleteDTO) {
		return new ResponseEntity<>(deviceService.deleteDevice(sn,deviceDeleteDTO), HttpStatus.OK);
	}

}
