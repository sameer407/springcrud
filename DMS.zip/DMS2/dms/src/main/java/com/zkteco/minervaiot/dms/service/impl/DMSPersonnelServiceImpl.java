//package com.zkteco.minervaiot.dms.service.impl;
//
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.http.HttpEntity;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.HttpMethod;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.MediaType;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Service;
//import org.springframework.web.client.RestTemplate;
//import org.springframework.web.util.UriComponentsBuilder;
//
//import com.fasterxml.jackson.core.type.TypeReference;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.nimbusds.jose.shaded.json.JSONObject;
//import com.zkteco.minervaiot.dms.config.MessageConfig;
//import com.zkteco.minervaiot.dms.dto.PersonnelData;
//import com.zkteco.minervaiot.dms.service.DMSPersonnelService;
//import com.zkteco.minervaiot.dms.util.ResultEntity;
//
//@Service
//public class DMSPersonnelServiceImpl implements DMSPersonnelService {
//
//	@Value("${dbs.url}")
//	private String baseUrl;
//
//	@Value("${dbs.url.getToken}")
//	private String getToken;
//
//	@Value("${dbs.url.syncPersonnelInformation}")
//	private String syncPersonnal;
//
//	@Value("${dbs.url.batchSyncPersonnelInformation}")
//	private String batchSyncPersonnalInformation;
//
//	@Value("${dbs.url.removePersonnel}")
//	private String removePersonnal;
//
//	@Value("${dbs.url.removeBatchPersonnel}")
//	private String removeBatchPersonnal;
//
//	@Value("${dbs.url.syncPersonnelFacePhoto}")
//	private String syncPersonnalFacePhoto;
//
//	@Value("${dbs.url.removeBiometricTemplate}")
//	private String removeBiometricTemplate;
//
//	@Autowired
//	RestTemplate restTemplate;
//
//	@Autowired
//	private ObjectMapper objMap;
//
//	private String tokenExpire;
//
//	private String accessToken;
//	
//	@Autowired 
//	private MessageConfig message;
//
//	@Override
//	public ResponseEntity<ResultEntity> syncPersonnel(String jsonStr) {
//		ResultEntity res = new ResultEntity();
//		try {
//			HttpHeaders headers = new HttpHeaders();
//			Map<String, Object> requestBody = new HashMap<>();
//			Map<String, Object> payload = new HashMap<>();
//			Map<String, Object> params = new HashMap<String, Object>();
//			JSONObject json = JSONObject.parseObject(jsonStr);
//
//			PersonnelData attPersonDTO = objMap.readValue(json.get("attPerson").toString(),
//					new TypeReference<PersonnelData>() {
//					});
//
//			if (accessToken != null && StringUtils.isNotBlank(accessToken)) {
//				headers.set("Authorization", accessToken);
//				headers.setContentType(MediaType.APPLICATION_JSON);
//
//				payload.put("params", attPersonDTO);
//				requestBody.put("lang", "en");
//				requestBody.put("payload", payload);
//
//				String reqBody = objMap.writeValueAsString(requestBody);
//				HttpEntity<String> entity = new HttpEntity<>(reqBody, headers);
//
//				String response = restTemplate.exchange(baseUrl + syncPersonnal, HttpMethod.POST, entity, String.class)
//						.getBody();
//
//				JSONObject responseJSON = JSONObject.parseObject(response);
//				res.setCode("00000000");
//				res.setMsg(message.locale("00000000"));
//				res.setData(responseJSON.get("payload"));
//			} else {
//				getAccessToken();
//				syncPersonnel(jsonStr);
//			}
//		} catch (Exception ex) {
//			res.setCode("POSE0001");
//			res.setMsg(message.locale("POSE0001"));
//			res.setData(ex.getMessage());
//		}
//		return new ResponseEntity<ResultEntity>(res, HttpStatus.OK);
//	}
//
//	@Override
//	public ResponseEntity<ResultEntity> batchSyncPersonnelInformation(String jsonStr) {
//		ResultEntity res = new ResultEntity();
//		try {
//			HttpHeaders headers = new HttpHeaders();
//			Map<String, Object> requestBody = new HashMap<>();
//			Map<String, Map> payload = new HashMap<>();
//			Map<String, Object> params = new HashMap<String, Object>();
//			JSONObject json = JSONObject.parseObject(jsonStr);
//			
//			String sn = json.getString("sn");
//
//			List<PersonnelData> attPersonDTO = objMap.readValue(json.get("person").toString(),
//					new TypeReference<List<PersonnelData>>() {
//					});
//
//			if (accessToken != null && StringUtils.isNotBlank(accessToken)) {
//				headers.set("Authorization", accessToken);
//				headers.setContentType(MediaType.APPLICATION_JSON);
//				
//				params.put("sn", sn);
//				params.put("users", attPersonDTO);
//
//				payload.put("params", params);
//				requestBody.put("lang", "en");
//				requestBody.put("payload", payload);
//
//				String reqBody = objMap.writeValueAsString(requestBody);
//				HttpEntity<String> entity = new HttpEntity<>(reqBody, headers);
//
//				String response = restTemplate
//						.exchange(baseUrl + batchSyncPersonnalInformation, HttpMethod.POST, entity, String.class)
//						.getBody();
//
//				JSONObject responseJSON = JSONObject.parseObject(response);
//				res.setCode("00000000");
//				res.setMsg(message.locale("00000000"));
//				res.setData(responseJSON.get("payload"));
//			} else {
//				getAccessToken();
//				batchSyncPersonnelInformation(jsonStr);
//			}
//		} catch (Exception ex) {
//			res.setCode("POSE0002");
//			res.setMsg(message.locale("POSE0002"));
//			res.setData(ex.getMessage());
//		}
//		return new ResponseEntity<ResultEntity>(res, HttpStatus.OK);
//	}
//
//	@Override
//	public ResponseEntity<ResultEntity> removePersonnel(String jsonStr) {
//		ResultEntity res = new ResultEntity();
//		try {
//			HttpHeaders headers = new HttpHeaders();
//			Map<String, Object> requestBody = new HashMap<>();
//			Map<String, Map> payload = new HashMap<>();
//			Map<String, String> params = new HashMap<String, String>();
//			JSONObject json = JSONObject.parseObject(jsonStr);
//
//			String sn = json.getString("sn");
//			String pin = json.getString("pin");
//
//			if (accessToken != null && StringUtils.isNotBlank(accessToken)) {
//				headers.set("Authorization", accessToken);
//				headers.setContentType(MediaType.APPLICATION_JSON);
//
//				params.put("sn", sn);
//				params.put("pin", pin);
//				
//				payload.put("params", params);
//				requestBody.put("lang", "en");
//				requestBody.put("payload", payload);
//				String reqBody = objMap.writeValueAsString(requestBody);
//				HttpEntity<String> entity = new HttpEntity<>(reqBody, headers);
//				String response = restTemplate
//						.exchange(baseUrl + removePersonnal, HttpMethod.POST, entity, String.class).getBody();
//				JSONObject responseJSON = JSONObject.parseObject(response);
//				res.setCode("00000000");
//				res.setMsg(message.locale("00000000"));
//				res.setData(responseJSON.get("payload"));
//			} else {
//				getAccessToken();
//				removePersonnel(jsonStr);
//			}
//		} catch (Exception ex) {
//			res.setCode("POSE0003");
//			res.setMsg(message.locale("POSE0003"));
//			res.setData(ex.getMessage());
//		}
//		return new ResponseEntity<ResultEntity>(res, HttpStatus.OK);
//	}
//
//	@Override
//	public ResponseEntity<ResultEntity> removeBatchPersonnel(String jsonStr) {
//		ResultEntity res = new ResultEntity();
//		try {
//			HttpHeaders headers = new HttpHeaders();
//			Map<String, Object> requestBody = new HashMap<>();
//			Map<String, Map> payload = new HashMap<>();
//			Map<String, Object> params = new HashMap<String, Object>();
//			JSONObject json = JSONObject.parseObject(jsonStr);
//
//			String sn = json.getString("sn");
//			List<String> pins = objMap.readValue(json.get("pins").toString(),
//					new TypeReference<List<String>>() {
//					});
//
//			if (accessToken != null && StringUtils.isNotBlank(accessToken)) {
//				headers.set("Authorization", accessToken);
//				headers.setContentType(MediaType.APPLICATION_JSON);
//
//				params.put("sn", sn);
//				params.put("pins", pins);
//				
//				payload.put("params", params);
//				requestBody.put("lang", "en");
//				requestBody.put("payload", payload);
//				String reqBody = objMap.writeValueAsString(requestBody);
//				HttpEntity<String> entity = new HttpEntity<>(reqBody, headers);
//				String response = restTemplate
//
//						.exchange(baseUrl + removeBatchPersonnal, HttpMethod.POST, entity, String.class).getBody();
//				JSONObject responseJSON = JSONObject.parseObject(response);
//				res.setCode("00000000");
//				res.setMsg(message.locale("00000000"));
//				res.setData(responseJSON.get("payload"));
//			} else {
//				getAccessToken();
//				removeBatchPersonnel(jsonStr);
//			}
//		} catch (Exception ex) {
//			res.setCode("POSE0004");
//			res.setMsg(message.locale("POSE0004"));
//			res.setData(ex.getMessage());
//		}
//		return new ResponseEntity<ResultEntity>(res, HttpStatus.OK);
//	}
//
//	@Override
//	public ResponseEntity<ResultEntity> syncPersonnelFacePhoto(String jsonStr) {
//		ResultEntity res = new ResultEntity();
//		try {
//			HttpHeaders headers = new HttpHeaders();
//			Map<String, Object> requestBody = new HashMap<>();
//			Map<String, Map> payload = new HashMap<>();
//			Map<String, String> params = new HashMap<String, String>();
//			JSONObject json = JSONObject.parseObject(jsonStr);
//
//			String sn = json.getString("sn");
//			String pin = json.getString("pin");
//			String facePhotoEncryption = json.getString("facePhotoEncryption");
//
//			if (accessToken != null && StringUtils.isNotBlank(accessToken)) {
//				headers.set("Authorization", accessToken);
//				headers.setContentType(MediaType.APPLICATION_JSON);
//
//				params.put("sn", sn);
//				params.put("pin", pin);
//				params.put("facePhotoEncryption", facePhotoEncryption);
//				
//				payload.put("params", params);
//				requestBody.put("lang", "en");
//				requestBody.put("payload", payload);
//				String reqBody = objMap.writeValueAsString(requestBody);
//				HttpEntity<String> entity = new HttpEntity<>(reqBody, headers);
//				String response = restTemplate
//
//						.exchange(baseUrl + removeBatchPersonnal, HttpMethod.POST, entity, String.class).getBody();
//				JSONObject responseJSON = JSONObject.parseObject(response);
//				res.setCode("00000000");
//				res.setMsg(message.locale("00000000"));
//				res.setData(responseJSON.get("payload"));
//			} else {
//				getAccessToken();
//				removeBatchPersonnel(jsonStr);
//			}
//		} catch (Exception ex) {
//			res.setCode("POSE0005");
//			res.setMsg(message.locale("POSE0005"));
//			res.setData(ex.getMessage());
//		}
//		return new ResponseEntity<ResultEntity>(res, HttpStatus.OK);
//	}
//
//	// @Override
//	public ResponseEntity<ResultEntity> removeBiometricTemplate(String jsonStr) {
//		ResultEntity res = new ResultEntity();
//		try {
//			HttpHeaders headers = new HttpHeaders();
//			Map<String, Object> requestBody = new HashMap<>();
//			Map<String, Map> payload = new HashMap<>();
//			Map<String, String> params = new HashMap<String, String>();
//			JSONObject json = JSONObject.parseObject(jsonStr);
//
//			String sn = json.getString("sn");
//			String pin = json.getString("pin");
//			String type = json.getString("type");
//
//			if (accessToken != null && StringUtils.isNotBlank(accessToken)) {
//				headers.set("Authorization", accessToken);
//				headers.setContentType(MediaType.APPLICATION_JSON);
//
//				params.put("sn", sn);
//				params.put("pin", pin);
//				params.put("type", type);
//				
//				payload.put("params", params);
//				requestBody.put("lang", "en");
//				requestBody.put("payload", payload);
//				String reqBody = objMap.writeValueAsString(requestBody);
//				HttpEntity<String> entity = new HttpEntity<>(reqBody, headers);
//				String response = restTemplate
//
//						.exchange(baseUrl + removeBatchPersonnal, HttpMethod.POST, entity, String.class).getBody();
//				JSONObject responseJSON = JSONObject.parseObject(response);
//				res.setCode("00000000");
//				res.setMsg(message.locale("00000000"));
//				res.setData(responseJSON.get("payload"));
//			} else {
//				getAccessToken(); 
//				removeBatchPersonnel(jsonStr);
//			}
//		} catch (Exception ex) {
//			res.setCode("POSE0006");
//			res.setMsg(message.locale("POSE0006"));
//			res.setData(ex.getMessage());
//		}
//		return new ResponseEntity<ResultEntity>(res, HttpStatus.OK);
//	}
//
//	public void getAccessToken() {
//		try {
//			String code = "";
//			HttpHeaders headers = new HttpHeaders();
//			headers.set("", "");
//			HttpEntity<String> entity = new HttpEntity<>(headers);
//
//			Map<String, String> urlParams = new HashMap<>();
//
//			UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(baseUrl + getToken)
//					.queryParam("appKey", "11d98b6a096c429cbde5c7c5c58c5655").queryParam("timestamp", "1529223702")
//					.queryParam("sign", "f767723c1c017cd0b29ec3953d1c4da9");
//
//			String response = restTemplate.exchange(builder.build().toUri(), HttpMethod.POST, entity, String.class)
//					.getBody();
//			JSONObject json = JSONObject.parseObject(response);
//			code = json.getString("code");
//
//			accessToken = json.get("accessToken").toString();
//			tokenExpire = json.get("expiresIn").toString();
//		} catch (Exception ex) {
//			ex.printStackTrace();
//		}
//
//	}
//
//}
