// package com.zkteco.minervaiot.dms.controller;
//
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.http.ResponseEntity;
// import org.springframework.web.bind.annotation.PostMapping;
// import org.springframework.web.bind.annotation.RequestBody;
// import org.springframework.web.bind.annotation.RequestMapping;
// import org.springframework.web.bind.annotation.RestController;
//
// import com.zkteco.minervaiot.dms.service.DMSOperationService;
// import com.zkteco.minervaiot.dms.util.ResultEntity;
//
// @RestController
// @RequestMapping(value = "/api/dev-mgn")
// public class DMSOperationsController {
//
// @Autowired
// private DMSOperationService dbsOperationService;
//
// @PostMapping(value = "addDevice")
// public ResponseEntity<ResultEntity> addDevice(@RequestBody String jsonStr) {
// ResultEntity result = new ResultEntity();
// ResponseEntity<ResultEntity> requestEntity =
// dbsOperationService.addDevice(jsonStr);
// return requestEntity;
// }
//
// @PostMapping(value = "modifyDevice")
// public ResponseEntity<ResultEntity> modifyDevice(@RequestBody String jsonStr)
// {
// ResultEntity result = new ResultEntity();
// ResponseEntity<ResultEntity> requestEntity =
// dbsOperationService.modifyDevice(jsonStr);
// return requestEntity;
// }
//
// @PostMapping(value = "deleteDevice")
// public ResponseEntity<ResultEntity> deleteDevice(@RequestBody String jsonStr)
// {
// ResultEntity result = new ResultEntity();
// ResponseEntity<ResultEntity> requestEntity =
// dbsOperationService.deleteDevice(jsonStr);
// return requestEntity;
// }
//
// @PostMapping(value = "restartDevice")
// public ResponseEntity<ResultEntity> restartDevice(@RequestBody String
// jsonStr) {
// ResultEntity result = new ResultEntity();
// ResponseEntity<ResultEntity> requestEntity =
// dbsOperationService.rebootDevice(jsonStr);
// return requestEntity;
// }
//
// @PostMapping(value = "enableDevice")
// public ResponseEntity<ResultEntity> enableDevice(@RequestBody String jsonStr)
// {
// ResultEntity result = new ResultEntity();
// ResponseEntity<ResultEntity> requestEntity =
// dbsOperationService.enableDevice(jsonStr);
// return requestEntity;
// }
//
// @PostMapping(value = "disableDevice")
// public ResponseEntity<ResultEntity> disableDevice(@RequestBody String
// jsonStr) {
// ResultEntity result = new ResultEntity();
// ResponseEntity<ResultEntity> requestEntity =
// dbsOperationService.disableDevice(jsonStr);
// return requestEntity;
// }
//
// @PostMapping(value = "uploadAttRecord")
// public ResponseEntity<ResultEntity> uploadAttRecord(@RequestBody String
// jsonStr) {
// ResultEntity result = new ResultEntity();
// ResponseEntity<ResultEntity> requestEntity =
// dbsOperationService.uploadAttRecord(jsonStr);
// return requestEntity;
// }
//
// @PostMapping(value = "uploadPersonRecord")
// public ResponseEntity<ResultEntity> uploadPersonRecord(@RequestBody String
// jsonStr) {
// ResultEntity result = new ResultEntity();
// ResponseEntity<ResultEntity> requestEntity =
// dbsOperationService.uploadPersonRecord(jsonStr);
// return requestEntity;
// }
//
// @PostMapping(value = "registerBiometrics")
// public ResponseEntity<ResultEntity> registerBiometrics(@RequestBody String
// jsonStr) {
// ResultEntity result = new ResultEntity();
// ResponseEntity<ResultEntity> requestEntity =
// dbsOperationService.registerBiometrics(jsonStr);
// return requestEntity;
// }
//
// @PostMapping(value = "cancelBiometrics")
// public ResponseEntity<ResultEntity> cancelBiometrics(@RequestBody String
// jsonStr) {
// ResultEntity result = new ResultEntity();
// ResponseEntity<ResultEntity> requestEntity =
// dbsOperationService.cancelBiometrics(jsonStr);
// return requestEntity;
// }
//
// @PostMapping(value = "queryDeviceInfo")
// public ResponseEntity<ResultEntity> queryDeviceInfo(@RequestBody String
// jsonStr) {
// ResultEntity result = new ResultEntity();
// ResponseEntity<ResultEntity> requestEntity =
// dbsOperationService.queryDeviceInfo(jsonStr);
// return requestEntity;
// }
//
// @PostMapping(value = "queryCommandInfo")
// public ResponseEntity<ResultEntity> queryCommandInfo(@RequestBody String
// jsonStr) {
// ResultEntity result = new ResultEntity();
// ResponseEntity<ResultEntity> requestEntity =
// dbsOperationService.queryDeviceCommand(jsonStr);
// return requestEntity;
// }
// }
