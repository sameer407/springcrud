package com.zkteco.minervaiot.dms.service;

import com.amazonaws.services.iot.client.AWSIotException;
import com.amazonaws.services.iot.client.AWSIotMessage;

public interface AWSIOTService {

    public void publish(AWSIotMessage awsIotMessage);

}
