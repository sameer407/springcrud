package com.zkteco.minervaiot.dms.service;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.zkteco.minervaiot.dms.dataobject.BaseDO;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

@Entity
@Table(name = "DEVICE_SECRETNO")
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
public class DeviceSecretnoDO extends BaseDO implements Serializable {
	//
	private static final long serialVersionUID = 1L;

	@Column(name = "sn", length = 100, nullable = false)
	private String sn;

	@Column(name = "secret_no", length = 100, nullable = false)
	private String secretNo;
}
