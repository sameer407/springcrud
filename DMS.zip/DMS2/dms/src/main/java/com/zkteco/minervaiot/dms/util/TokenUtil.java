package com.zkteco.minervaiot.dms.util;

import com.zkteco.minervaiot.dms.constants.ParamsConstants;
import com.zkteco.minervaiot.dms.dto.TokenResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.util.Objects;

@Component
public class TokenUtil {
    @Autowired
    private HttpServletRequest request;

    public TokenResponseDTO getTokenData(){
       Object object = request.getAttribute(ParamsConstants.TOKEN_DATA);
       if(Objects.isNull(object)){
           return null;
       }
        return (TokenResponseDTO)object;
    }
}
