package com.zkteco.minervaiot.dms.constants;


/**
 * ParamsConstants
 *
 * @author howard.liu
 * @date 2021/12/15 15:43
 * @since 1.0.0
 */
public class ParamsConstants {
    public final static String TOKEN_DATA = "tokenData";


}
