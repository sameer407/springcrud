package com.zkteco.minervaiot.dms.config.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zkteco.minervaiot.dms.constants.ParamsConstants;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import com.zkteco.minervaiot.dms.dto.TokenResponseDTO;
import com.zkteco.minervaiot.dms.exception.InvalidTokenException;
import com.zkteco.minervaiot.dms.util.BasicUtil;

@Component
public class CustomHeaderInterceptor implements HandlerInterceptor {

	CheckBearerToken checkBearerToken;

	public CustomHeaderInterceptor(CheckBearerToken checkBearerToken) {
		this.checkBearerToken = checkBearerToken;
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		String requestURI = request.getRequestURI();
		if (requestURI.contains("/api/")) {
			return true;
		}
		TokenResponseDTO tokenBody = checkBearerToken.checkAccesstoken(request, response);
		if (tokenBody.getCode()!=null) {
			throw new InvalidTokenException(tokenBody.getMessage());
		} else {
			request.setAttribute(ParamsConstants.TOKEN_DATA,tokenBody);
			return true;
		}

	}

}
