package com.zkteco.minervaiot.dms.service.v3;

import java.util.List;

import com.zkteco.minervaiot.dms.dto.DeviceDTO;
import com.zkteco.minervaiot.dms.util.Result;

public interface DeviceServiceV3 {


	public Result createDevice(DeviceDTO deviceDTO);

	public Result createDevicesByBatch(List<DeviceDTO> deviceDTO);

	public Result mapDevice(String sn, String companyCode);

	public Result mapCertificate(String sn, String devCertificate);

	public Result getCertificate(String sn);
	

}
