package com.zkteco.minervaiot.dms.dto;

import com.google.common.collect.Maps;
import lombok.Data;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

@Data
public class CommandPayload {
    private String cmd_type;
    private String cmd_id;
    private String priority;
    private String timestamp;
    private String version;
    private Map data;


    public CommandPayload() {


    }

    public CommandPayload(String cmdType, String cmdId, String priority, String timestamp, String version) {
        this.cmd_type = cmdType;
        this.cmd_id = cmdId;
        this.priority = priority;
        this.timestamp = timestamp;
        this.version = version;
        this.data = Maps.newLinkedHashMap();
    }

}
