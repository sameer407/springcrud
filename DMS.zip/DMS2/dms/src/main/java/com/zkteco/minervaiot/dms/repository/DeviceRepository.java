package com.zkteco.minervaiot.dms.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.zkteco.minervaiot.dms.dataobject.DeviceDO;

public interface DeviceRepository extends JpaRepository<DeviceDO, String>, JpaSpecificationExecutor<DeviceDO> {

	@Query(value = "select reader from DeviceDO reader where ((:sn='' or reader.sn=:sn) and (:mac='' or reader.mac=:mac) and (:productCode='' or reader.productCode=:productCode) and (:deviceAlias='' or reader.deviceAlias=:deviceAlias))")
	Page<DeviceDO> findByFilter(@Param("sn") String sn, @Param("mac") String mac, @Param("productCode") String productCode,
			@Param("deviceAlias") String deviceAlias, Pageable paging);

	DeviceDO findBySn(String sn);

	DeviceDO findBySnIgnoreCaseAndIdNot(String sn, String id);

}
