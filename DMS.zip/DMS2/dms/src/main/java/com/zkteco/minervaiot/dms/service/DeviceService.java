package com.zkteco.minervaiot.dms.service;

import java.util.List;

import com.zkteco.minervaiot.dms.dto.DeviceDTO;
import com.zkteco.minervaiot.dms.dto.DeviceDeleteDTO;
import com.zkteco.minervaiot.dms.util.Result;

public interface DeviceService {

	public Result saveDeviceSecretNo(String deviceSn);

	public Result createDevices(DeviceDTO deviceDTO);

	public Result updateDevices(String sn, DeviceDTO deviceDTO);

	public Result findByfilter(int pageNumber, int pageSize, String deviceSn, String mac, String productCode, String deviceAlias);

	Result getDeviceSecretNo(String deviceSn);

	public Result addOrUpdateDevice(List<DeviceDTO> deviceDTO);

	/**
	 * @Description: Get whether the current device is under the company
	 * @Author: aili.hu
	 * @Param: deviceSn
	 * @return: Result
	 * @Date: 9:29 2021/12/15
	*/
	Result getDeviceBindCompany(String deviceSn);

	Result deleteDevice(String deviceSn, DeviceDeleteDTO deviceDeleteDTO);

}
