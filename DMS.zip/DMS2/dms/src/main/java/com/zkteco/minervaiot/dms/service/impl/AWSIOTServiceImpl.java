package com.zkteco.minervaiot.dms.service.impl;

import com.amazonaws.services.iot.client.AWSIotException;
import com.amazonaws.services.iot.client.AWSIotMessage;
import com.amazonaws.services.iot.client.AWSIotMqttClient;
import com.zkteco.minervaiot.dms.awsiot.client.AWSIOTMQTTClient;
import com.zkteco.minervaiot.dms.service.AWSIOTService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AWSIOTServiceImpl implements AWSIOTService {

    @Autowired
    AWSIotMqttClient awsIotMqttClient;

    @Override
    public void publish(AWSIotMessage awsIotMessage){
        try {
            awsIotMqttClient.publish(awsIotMessage);
        }catch (AWSIotException awsIotException){
            log.error("send message error ",awsIotException);
        }
    }

}
