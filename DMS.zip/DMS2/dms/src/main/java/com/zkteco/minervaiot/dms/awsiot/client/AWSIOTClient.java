package com.zkteco.minervaiot.dms.awsiot.client;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.iot.AWSIot;
import com.amazonaws.services.iot.AWSIotClientBuilder;
import com.amazonaws.services.iot.model.*;
import com.amazonaws.services.iotdata.AWSIotData;
import com.amazonaws.services.iotdata.AWSIotDataClientBuilder;
import com.amazonaws.services.iotdata.model.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;


@Configuration
@Slf4j
public class AWSIOTClient {

    @Value("${amazon.aws.accesskey}")
    public String amazonAWSAccessKey;

    @Value("${amazon.aws.secretkey}")
    public String amazonAWSSecretKey;

    @Value("${amazon.aws.region}")
    public String amazonAWSRegion;

    @Value("${amazon.aws.iotdataendpoint}")
    public String iotDataEndpoint;

    @Bean
    public AWSIot awsIot(){
        return createIotService();
    }

    private AWSIot createIotService(){
        AWSCredentials credentials = new BasicAWSCredentials(amazonAWSAccessKey, amazonAWSSecretKey);
        AWSCredentialsProvider credentialsProvider = new AWSStaticCredentialsProvider(credentials);
        AWSIotClientBuilder awsIOT = AWSIotClientBuilder.standard();
        awsIOT.setCredentials(credentialsProvider);
        awsIOT.setRegion(amazonAWSRegion);
        return awsIOT.build();
    }

    @Bean
    public AWSIotData awsIotData(){
        return configAWSIotDataClient();
    }

    private AWSIotData configAWSIotDataClient() {
        AWSCredentials credentials = new BasicAWSCredentials(amazonAWSAccessKey, amazonAWSSecretKey);
        AwsClientBuilder.EndpointConfiguration endpointConfiguration = new AwsClientBuilder.EndpointConfiguration(iotDataEndpoint, amazonAWSRegion);
        AWSCredentialsProvider credentialsProvider = new AWSStaticCredentialsProvider(credentials);
        AWSIotDataClientBuilder awsIOTDataClientBuilder = AWSIotDataClientBuilder.standard();
        awsIOTDataClientBuilder.setCredentials(credentialsProvider);
        awsIOTDataClientBuilder.setEndpointConfiguration(endpointConfiguration);
        return awsIOTDataClientBuilder.build();
    }
}
