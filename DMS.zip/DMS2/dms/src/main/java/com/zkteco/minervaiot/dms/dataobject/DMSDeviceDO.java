package com.zkteco.minervaiot.dms.dataobject;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Data;

@Entity
@Data
@Table(name = "DMS_DEVICE")
public class DMSDeviceDO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
	@Column(name = "ID", length = 50, nullable = false)
	public String id;

	@Column(name = "CREATED_AT", updatable = false)
	@Temporal(TemporalType.TIMESTAMP)
	@CreationTimestamp
	protected Date createdAt;

	@Column(name = "UPDATED_AT")
	@Temporal(TemporalType.TIMESTAMP)
	@UpdateTimestamp
	protected Date updatedAt;

	@Column(name = "COMPANY_ID",length = 50, nullable = false)
	protected String companyId;
	
	@Column(name = "COMPANY_Code",length = 50, nullable = false)
	protected String companyCode;
	
	@Column(name = "DEVICE_SN", length = 60, unique = true, nullable = false)
	private String sn;

	@Column(name = "DEVICE_ALIAS", length = 50)
	private String deviceAlias;

	@Column(name = "DEVICE_TYPE", length = 30,nullable = false)
	private String deviceType;
	
	@Column(name = "DEVICE_MODULE", length = 50)
	private String deviceModel;
	
	@Column(name = "FW_VERSION", length = 50)
	private String fwVersion;
	
	@Column(name = "PROTOCOL_VERSION", length = 50)
	private String protocolVersion;
	
	@Column(name = "DEVICE_MANAGER", length = 30,nullable = false)
	private String deviceManager;
	
	@Column(name = "MAC", length = 50)
	private String mac;
	
	@Column(name = "PACKING_TIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date packingTime;
	
	@Column(name = "DEVICE_PLATFORM", length = 50)
	private String devicePlatform;
	
	@Column(name = "CLIENT_COUNTRY", length = 30)
	private String clientCountry;
	
	@Column(name = "CLIENT_NAME", length = 100)
	private String clientName;
	
	@Column(name = "PRODUCTION_ORDER_NUMBER", length = 60)
	private String productionOrderNumber;
	
	@Column(name = "BOM_VERSION", length = 30)
	private String bomVersion;
	
	@Column(name = "FEATURES_ID", length = 50)
	private String featuresId;
	
	@Column(name = "MATERIAL_NUMBER", length = 40)
	private String materialNumber;
	
	@Column(name = "PRODUCT_CODE", length = 40)
	private String productCode;
	
	@Column(name = "MATERIAL_NAME", length = 50)
	private String materialName;
}
