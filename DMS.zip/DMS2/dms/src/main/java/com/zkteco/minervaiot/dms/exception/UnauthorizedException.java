package com.zkteco.minervaiot.dms.exception;

public class UnauthorizedException extends RuntimeException {
	private static final long serialVersionUID = -1252111496844488287L;

	public UnauthorizedException(String message) {
		super(message);
	}
}
