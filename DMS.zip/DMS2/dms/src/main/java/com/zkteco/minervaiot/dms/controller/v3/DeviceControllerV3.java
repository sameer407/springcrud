package com.zkteco.minervaiot.dms.controller.v3;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zkteco.minervaiot.dms.dto.DeviceDTO;
import com.zkteco.minervaiot.dms.service.v3.DeviceServiceV3;
import com.zkteco.minervaiot.dms.util.Result;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/v3")
@Api(tags = "Device", description = "This is the Device related API's.")
public class DeviceControllerV3 {

	@Autowired
	DeviceServiceV3 deviceService;

	

	/* This API is used to create Device */

	
	  @ApiOperation(value = "Add Device", httpMethod = "POST", response =
	  Result.class)
	  
	  @ApiResponses(value = {@ApiResponse(code = 200, message ="Successfully Created Device"),
			  @ApiResponse(code = 400, message = "Invalid input format."), @ApiResponse(code = 401, message = "Unauthorized access.")})
	  
	  @PostMapping("/device") public ResponseEntity<Result>
	  createDevice(@RequestBody DeviceDTO deviceDTO) { return new
	  ResponseEntity<>(deviceService.createDevice(deviceDTO), HttpStatus.OK); }
	  
	  
	/* This API is used to create  devices by batch */

		@ApiOperation(value = "Add Device By Batch", httpMethod = "POST", response = Result.class)
		@ApiResponses(value = {@ApiResponse(code = 200, message = "Successfully Created Device"),
				@ApiResponse(code = 400, message = "Invalid input format."), @ApiResponse(code = 401, message = "Unauthorized access.")})
		@PostMapping("/devices")
		public ResponseEntity<Result> createDevicesByBatch(@RequestBody List<DeviceDTO> deviceDTO) {
			return new ResponseEntity<>(deviceService.createDevicesByBatch(deviceDTO), HttpStatus.OK);
		}
		
    /* This API is used to Map  device with Company Code */

		@ApiOperation(value = "Map  devices with Company Code", httpMethod = "PUT", response = Result.class)
		@ApiResponses(value = {@ApiResponse(code = 200, message = "Successfully Maped Device"),
				@ApiResponse(code = 400, message = "Invalid input format."), @ApiResponse(code = 401, message = "Unauthorized access.")})
		@PutMapping("/mapdev/{sn}/{companyCode}") 
		public ResponseEntity<Result>mapDevice(@PathVariable(value = "sn") String sn,@PathVariable(value = "companyCode") String companyCode) { 
			return new ResponseEntity<>(deviceService.mapDevice(sn,companyCode), HttpStatus.OK); }
	 
		
		/* This API is used to Map  device with certificate */

		@ApiOperation(value = "Map  device with certificate", httpMethod = "PUT", response = Result.class)
		@ApiResponses(value = {@ApiResponse(code = 200, message = "Successfully Maped Device"),
				@ApiResponse(code = 400, message = "Invalid input format."), @ApiResponse(code = 401, message = "Unauthorized access.")})
		@PutMapping("/certificate/{sn}/{certificate}") 
		public ResponseEntity<Result>mapCertificate(@PathVariable(value = "sn") String sn,@PathVariable(value = "certificate") String devCertificate) { 
			return new ResponseEntity<>(deviceService.mapCertificate(sn,devCertificate), HttpStatus.OK); }

		
		/* This API is used to fet  device certificate */

		@ApiOperation(value = "Get  device certificate", httpMethod = "GET", response = Result.class)
		@ApiResponses(value = {@ApiResponse(code = 200, message = "Success"),
				@ApiResponse(code = 400, message = "Invalid input format."), @ApiResponse(code = 401, message = "Unauthorized access.")})
		@GetMapping("/certificate/{sn}") 
		public ResponseEntity<Result>getCertificate(@PathVariable(value = "sn") String sn) { 
			return new ResponseEntity<>(deviceService.getCertificate(sn), HttpStatus.OK); }
		


	

}
