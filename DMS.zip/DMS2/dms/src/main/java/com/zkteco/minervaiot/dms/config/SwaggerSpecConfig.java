package com.zkteco.minervaiot.dms.config;

import java.util.Arrays;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.zkteco.minervaiot.dms.config.security.SecurityConstant;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.Contact;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@EnableSwagger2
@Configuration
public class SwaggerSpecConfig {

	private static final String TITLE = "API Document For Device Management Service";
	private static final String TERMS = "NO terms of service";
	private static final String LICENSE = "ZKTeco India Global R & D Center";
	private static final String LICENSE_URL = "#";
	private static final String NAME = "Device Management Service";
	private static final String URL = "";
	private static final String EMAIL = "";
	private static final String DESCRIPTION_APP = "Device Management Service Document";

	@Bean
	public Docket apiV30() {
		return new Docket(DocumentationType.SWAGGER_2).groupName("v3").useDefaultResponseMessages(false).apiInfo(appApiInfo())
				.securityContexts(Arrays.asList(securityContext()))
				.securitySchemes(Arrays.asList(new ApiKey(SecurityConstant.JWT, SecurityConstant.AUTHORIZATION, SecurityConstant.HEADER)))
				.select().apis(RequestHandlerSelectors.basePackage("com.zkteco.minervaiot.dms.controller.v3"))
				.paths(PathSelectors.regex("/api/v3.*")).build();

	}
	
	@Bean
	public Docket apiV20() {
		return new Docket(DocumentationType.SWAGGER_2).groupName("v2.0").useDefaultResponseMessages(false).apiInfo(appApiInfo())
				.securityContexts(Arrays.asList(securityContext()))
				.securitySchemes(Arrays.asList(new ApiKey(SecurityConstant.JWT, SecurityConstant.AUTHORIZATION, SecurityConstant.HEADER)))
				.select().apis(RequestHandlerSelectors.basePackage("com.zkteco.minervaiot.dms.controller"))
				.paths(PathSelectors.regex("/api/v2.0.*")).build();

	}

	private SecurityContext securityContext() {
		return SecurityContext.builder().securityReferences(defaultAuth()).build();
	}
	
	private ApiInfo appApiInfoV3() {
		return new ApiInfoBuilder().title(TITLE).description(DESCRIPTION_APP).termsOfServiceUrl(TERMS)
				.contact(new Contact(NAME, URL, EMAIL)).license(LICENSE).licenseUrl(LICENSE_URL).version("3").build();
	}

	private ApiInfo appApiInfo() {
		return new ApiInfoBuilder().title(TITLE).description(DESCRIPTION_APP).termsOfServiceUrl(TERMS)
				.contact(new Contact(NAME, URL, EMAIL)).license(LICENSE).licenseUrl(LICENSE_URL).version("2.0").build();
	}
	
	
	private List<SecurityReference> defaultAuth() {
		AuthorizationScope authorizationScope = new AuthorizationScope("global", "accessEverything");
		AuthorizationScope[] authorizationScopes = new AuthorizationScope[1];
		authorizationScopes[0] = authorizationScope;
		return Arrays.asList(new SecurityReference(SecurityConstant.JWT, authorizationScopes));
	}
}