package com.zkteco.minervaiot.dms.service.impl;

import com.amazonaws.services.iot.client.AWSIotMessage;
import com.amazonaws.services.iot.client.AWSIotQos;
import com.zkteco.minervaiot.dms.constants.CommandTypeConstants;
import com.zkteco.minervaiot.dms.constants.MQTTConstants;
import com.zkteco.minervaiot.dms.dto.Command;
import com.zkteco.minervaiot.dms.dto.CommandPayload;
import com.zkteco.minervaiot.dms.service.AWSIOTService;
import com.zkteco.minervaiot.dms.service.CmdService;
import com.zkteco.minervaiot.dms.util.MQTTUtil;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CmdServiceImpl implements CmdService {

    @Autowired
    private AWSIOTService awsiotService;


    @Override
    public void issueDeleteDeviceCommand(Command command) {
        String topic = MQTTUtil.getTopic(command.getCompanyId(),command.getSiteId(),command.getSn());
        CommandPayload commandPayload = initDeleteDevice();
        AWSIotMessage deleteMessage = new AWSIotMessage(topic, AWSIotQos.QOS1, new JSONObject(commandPayload).toString());
        awsiotService.publish(deleteMessage);
    }

    /**
     *  init delete device payload
     *
     * @return com.zkteco.minervaiot.dms.dto.CommandPayload
     * @throws
     * @author howard.liu
     * @date 2021/12/15 17:02
     * @since 1.0.0
     */
    private  CommandPayload initDeleteDevice(){
        String cmdId = java.util.UUID.randomUUID().toString().replace("-", "");
        String timestamp = String.valueOf(System.currentTimeMillis());
        return  new CommandPayload(CommandTypeConstants.DELETE_DEVICE, cmdId, MQTTConstants.PRIORITY_ONE, timestamp, MQTTConstants.VERSION_V1);
    }
}
