package com.zkteco.minervaiot.dms.config.security;

import java.util.Base64;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.zkteco.minervaiot.dms.dto.TokenResponseDTO;
import com.zkteco.minervaiot.dms.exception.InvalidTokenException;
import com.zkteco.minervaiot.dms.exception.TokenNotFoundException;
import com.zkteco.minervaiot.dms.util.BasicUtil;

@Component
public class CheckBearerToken {
	@Value("${security.auth-url}")
	private String authServerURL;

	@Value("${security.check-token-uri}")
	private String checkTokenURI;

	@Value("${security.client-id}")
	private String clientId;

	@Value("${security.client-secret}")
	private String clientSecret;

	public TokenResponseDTO checkAccesstoken(HttpServletRequest request, HttpServletResponse response) throws JSONException {
		String token = request.getHeader(SecurityConstant.AUTHORIZATION);
		if (!BasicUtil.isNullOrEmpty(token) && token.startsWith(SecurityConstant.BEARER)) {
			token = token.replace(SecurityConstant.BEARER, "");
		} else {
			throw new TokenNotFoundException("token not found");
		}

		String basicToken = Base64.getEncoder().encodeToString((clientId + ":" + clientSecret).getBytes());

		HttpHeaders headers = new HttpHeaders();
		headers.add(SecurityConstant.AUTHORIZATION, SecurityConstant.BASIC + basicToken);
		HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(headers);
		RestTemplate restTemplate = new RestTemplate();
		try {
			ResponseEntity<TokenResponseDTO> apiResponse = restTemplate.exchange(authServerURL + checkTokenURI + "?token=" + token,
					HttpMethod.POST, entity, TokenResponseDTO.class);
			return apiResponse.getBody();
		} catch (HttpClientErrorException e) {
			JSONObject json = new JSONObject(e.getResponseBodyAsString());
			if (json.get("error").equals("invalid_token")) {
				throw new InvalidTokenException(json.getString("error_description"));
			}
		}
		return null;

	}
}
