package com.zkteco.minervaiot.dms.exception;

public class TokenNotFoundException extends RuntimeException {
	private static final long serialVersionUID = -1252111496844488287L;

	public TokenNotFoundException(String message) {
		super(message);
	}
}
