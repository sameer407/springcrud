package com.zkteco.minervaiot.dms.dto;



import java.sql.Date;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class DeviceDTO {

	@ApiModelProperty(name = "id", dataType = "String", value = "Device Id", example = "402894b47aed3906017aed10", position = 1, hidden = true)
	private String id;

	@ApiModelProperty(name = "sn", dataType = "String", value = "device sn", example = "001", position = 2)
	private String sn;

	@ApiModelProperty(name = "mac", dataType = "String", value = "mac", example = "abc123", position = 3)
	private String mac;

	@ApiModelProperty(name = "packingTime", dataType = "String", value = "packing Time", example = "2021-12-07 10:32:07.991", position = 4)
	private String packingTime;

	@ApiModelProperty(name = "deviceType", dataType = "String", value = "device Type", example = "Thumb scanner", position = 5)
	private String deviceType;
	
	@ApiModelProperty(name = "fwVersion", dataType = "String", value = "firmware version", example = "1.0_2022", position = 6)
	private String fwVersion;
	
	@ApiModelProperty(name = "protocolVersion", dataType = "String", value = "protocol version", example = "1.1", position = 7)
	private String protocolVersion;
	
	@ApiModelProperty(name = "devicePlatform", dataType = "String", value = "device Platform", example = "windows", position = 8)
	private String devicePlatform;

	@ApiModelProperty(name = "productionOrderNumber", dataType = "String", value = "production OrderNumber", example = "4b47aed39060", position = 9)
	private String productionOrderNumber;

	@ApiModelProperty(name = "bomVersion", dataType = "String", value = "bom Version", example = "version II", position = 10)
	private String bomVersion;

	@ApiModelProperty(name = "featuresId", dataType = "String", value = "features Id", example = "894b47aed3906017aed", position = 11)
	private String featuresId;

	@ApiModelProperty(name = "materialNumber", dataType = "String", value = "material Number", example = "402894b47aed3906017aed", position = 12)
	private String materialNumber;

	@ApiModelProperty(name = "productCode", dataType = "String", value = "product Code", example = "A9992", position = 13)
	private String productCode;

	@ApiModelProperty(name = "materialName", dataType = "String", value = "material Name", example = "Metal", position = 14)
	private String materialName;

	@ApiModelProperty(name = "deviceAlias", dataType = "String", value = "device Alias", example = "b012", position = 15)
	private String deviceAlias;

	@ApiModelProperty(name = "deviceModel", dataType = "String", value = "device Module", example = "dev", position = 16)
	private String deviceModel;

	@ApiModelProperty(name = "deviceManager", dataType = "String", value = "device Manager", example = "Android developers", position = 17)
	private String deviceManager;

	@ApiModelProperty(name = "manual", dataType = "String", value = "manual", example = "manual", position = 18)
	private String manual;

	@ApiModelProperty(name = "clientCountry", dataType = "String", value = "client country", example = "india", position = 19)
	private String clientCountry;
	
	@ApiModelProperty(name = "clientName", dataType = "String", value = "client name", example = "essl", position = 20)
	private String clientName;
	
	@ApiModelProperty(name = "location", dataType = "String", value = "location", example = "Bangalore", position = 21)
	private String location;
	
	@ApiModelProperty(name = "photo", dataType = "String", value = "device photo", example = "https://abc", position = 22)
	private String photo;

	@ApiModelProperty(hidden = true)
	private Date createdAt;

	@ApiModelProperty(hidden = true)
	private Date updatedAt;
}
