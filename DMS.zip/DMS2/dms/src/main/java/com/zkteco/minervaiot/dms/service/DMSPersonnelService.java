package com.zkteco.minervaiot.dms.service;

import org.springframework.http.ResponseEntity;

import com.zkteco.minervaiot.dms.util.ResultEntity;

public interface DMSPersonnelService {

	public ResponseEntity<ResultEntity> syncPersonnel(String jsonStr);
	
	public ResponseEntity<ResultEntity> batchSyncPersonnelInformation(String jsonStr);
	
	public ResponseEntity<ResultEntity> removePersonnel(String jsonStr);
	
	public ResponseEntity<ResultEntity> removeBatchPersonnel(String jsonStr);
	
	public ResponseEntity<ResultEntity> syncPersonnelFacePhoto(String jsonStr);
	
	public ResponseEntity<ResultEntity> removeBiometricTemplate(String jsonStr);
	
}
