package com.zkteco.minervaiot.dms.service.impl.v3;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zkteco.minervaiot.dms.dataobject.DeviceDO;
import com.zkteco.minervaiot.dms.dto.DeviceDTO;
import com.zkteco.minervaiot.dms.repository.DeviceRepository;
import com.zkteco.minervaiot.dms.service.v3.DeviceServiceV3;
import com.zkteco.minervaiot.dms.util.BasicUtil;
import com.zkteco.minervaiot.dms.util.ResponseCode;
import com.zkteco.minervaiot.dms.util.Result;

@Service
public class DeviceServiceImplV3 implements DeviceServiceV3 {

	@Autowired
	DeviceRepository deviceRepository;

	public static final String SUCCESS = "success";
	public static final String SUCCESS_COUNT = "successCount";
	public static final String ERROR = "error";
	public static final String ERROR_COUNT = "errorCount";
	public static final String DEVICE = "devices";
	public static final String REQUEST_DATA_COUNT = "total data in a request";

	

	@Override
	public Result createDevice(DeviceDTO deviceDTO) {
		DeviceDO deviceDo = deviceRepository.findBySn(deviceDTO.getSn());
		if (!BasicUtil.isNullOrEmpty(deviceDo)) {
			Map<String, String> responseMap = new LinkedHashMap<>();
			responseMap.put("id", deviceDo.getId());
			responseMap.put("sn", deviceDo.getSn());
			return BasicUtil.prepareResponseObject(ResponseCode.DMSE0002, responseMap);
		}

		DeviceDO deviceDO = new DeviceDO();
		BasicUtil.copyPropertiesIgnoreNull(deviceDTO, deviceDO);
		deviceRepository.save(deviceDO);
		Map<String, String> responseMap = new LinkedHashMap<>();
		responseMap.put("id", deviceDO.getId());
		responseMap.put("sn", deviceDO.getSn());
		return BasicUtil.prepareResponseObject(ResponseCode.DMSI0001, responseMap);
	}

	@Override
	public Result createDevicesByBatch(List<DeviceDTO> deviceDTO) {
		Map<String, Object> responseData = new LinkedHashMap<>();
		Map<String, String> responseMap = null;
		List<Result> successList = new ArrayList<>();
		List<Result> errorList = new ArrayList<>();

		if (deviceDTO.size() >= 1000) {
			return BasicUtil.prepareResponseObject(ResponseCode.DMSE0005, null);
		}

		for (DeviceDTO device : deviceDTO) {

				DeviceDO deviceDo = deviceRepository.findBySn(device.getSn());
				if (!BasicUtil.isNullOrEmpty(deviceDo)) {

					responseMap = new LinkedHashMap<>();
					responseMap.put("id", deviceDo.getId());
					responseMap.put("sn", deviceDo.getSn());
					errorList.add(BasicUtil.prepareResponseObject(ResponseCode.DMSE0002, responseMap));
				} else {

					DeviceDO deviceDO = new DeviceDO();
					BasicUtil.copyPropertiesIgnoreNull(device, deviceDO);
					deviceRepository.save(deviceDO);
					responseMap = new LinkedHashMap<>();
					responseMap.put("id", deviceDO.getId());
					responseMap.put("sn", deviceDO.getSn());
					successList.add(BasicUtil.prepareResponseObject(ResponseCode.DMSI0001, responseMap));
				}
			}

		responseData.put(REQUEST_DATA_COUNT, deviceDTO.size());
		responseData.put(SUCCESS_COUNT, successList.size());
		responseData.put(DEVICE, successList);
		responseData.put(ERROR_COUNT, errorList.size());
		responseData.put(ERROR, errorList);

		if (!errorList.isEmpty())
			return BasicUtil.prepareResponseObject(ResponseCode.DMSW0000, responseData);

		return BasicUtil.prepareResponseObject(ResponseCode.DMSI0000, responseData);
	}
	

	@Override
	public Result mapDevice(String sn, String companyCode) {
		DeviceDO deviceDo = deviceRepository.findBySn(sn);
		if (!BasicUtil.isNullOrEmpty(deviceDo)) {
			Map<String, String> responseMap = new LinkedHashMap<>();
			deviceDo.setCompanyCode(companyCode.toLowerCase());
			deviceRepository.save(deviceDo);
			responseMap.put("id", deviceDo.getId());
			responseMap.put("sn", deviceDo.getSn());
			responseMap.put("company_code", deviceDo.getCompanyCode());
			return BasicUtil.prepareResponseObject(ResponseCode.DMSI0004, responseMap);
		}
		Map<String, String> responseMap = new LinkedHashMap<>();
		responseMap.put("sn", sn);
		return BasicUtil.prepareResponseObject(ResponseCode.DMSE0003, responseMap);
	}
	
	@Override
	public Result mapCertificate(String sn, String devCertificate) {
		DeviceDO deviceDo = deviceRepository.findBySn(sn);
		if (!BasicUtil.isNullOrEmpty(deviceDo)) {
			Map<String, String> responseMap = new LinkedHashMap<>();
			deviceDo.setDevCertificate(devCertificate);
			deviceRepository.save(deviceDo);
			responseMap.put("id", deviceDo.getId());
			responseMap.put("sn", deviceDo.getSn());
			responseMap.put("certificate", deviceDo.getDevCertificate());
			return BasicUtil.prepareResponseObject(ResponseCode.DMSI0004, responseMap);
		}
		Map<String, String> responseMap = new LinkedHashMap<>();
		responseMap.put("sn", sn);
		return BasicUtil.prepareResponseObject(ResponseCode.DMSE0003, responseMap);
	}

	@Override
	public Result getCertificate(String sn) {
		DeviceDO deviceDo = deviceRepository.findBySn(sn);
		if (!BasicUtil.isNullOrEmpty(deviceDo)) {
			
		 if(!BasicUtil.isNullOrEmpty(deviceDo.getDevCertificate())) {
			Map<String, String> responseMap = new LinkedHashMap<>();
			responseMap.put("id", deviceDo.getId());
			responseMap.put("sn", deviceDo.getSn());
			responseMap.put("certificate", deviceDo.getDevCertificate());
			return BasicUtil.prepareResponseObject(ResponseCode.DMSI0000, responseMap);
		}
		 Map<String, String> responseMap = new LinkedHashMap<>();
		 responseMap.put("sn", sn);
		 return BasicUtil.prepareResponseObject(ResponseCode.DMSE0004, responseMap);
		}
		Map<String, String> responseMap = new LinkedHashMap<>();
		responseMap.put("sn", sn);
		return BasicUtil.prepareResponseObject(ResponseCode.DMSE0003, responseMap);
	}
	

}
