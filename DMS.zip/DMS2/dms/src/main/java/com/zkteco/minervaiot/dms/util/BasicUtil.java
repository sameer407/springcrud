package com.zkteco.minervaiot.dms.util;

import java.beans.PropertyDescriptor;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.zkteco.minervaiot.dms.config.MessageConfig;
import com.zkteco.minervaiot.dms.exception.BusinessException;

@Component
public class BasicUtil {
	//
	private static MessageConfig messageConfig;
	public static final String ENCRYPT_ALGO_SHA1 = "SHA-1";
	public static final String ENCRYPT_ALGO_SHA256 = "SHA-256";
	public static final String ENCRYPT_ALGO_SHA384 = "SHA-384";
	public static final String ENCRYPT_ALGO_SHA512 = "SHA-512";
	private static final char[] HEX_ARRAY = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
	static {
		messageConfig = new MessageConfig();
	}

	public static Result prepareResponseObject(String code, Object responseData) {
		Result result = new Result();
		result.setCode(code);
		result.setMessage(messageConfig.locale(code));
		if (isNullOrEmpty(responseData)) {
			result.setData(new EmptyJsonResponse());
		} else {
			result.setData(responseData);
		}
		return result;
	}

	public static Result prepareResponseObject(String code, String message, Object responseData) {
		Result result = new Result();
		result.setCode(code);
		result.setMessage(messageConfig.locale(code));
		String localeMessage = messageConfig.locale(code);
		if (localeMessage.length() == 8 && !isNullOrEmpty(message)) {
			result.setMessage(message);
		} else {
			result.setMessage(localeMessage);
		}
		if (isNullOrEmpty(responseData)) {
			result.setData(new EmptyJsonResponse());
		} else {
			result.setData(responseData);
		}
		return result;
	}

	public static Result prepareResponseObject(ResponseCode responseCode, Object responseData) {
		Result result = new Result();
		result.setCode(responseCode.name());
		result.setMessage(messageConfig.locale(responseCode.name()));
		if (isNullOrEmpty(responseData)) {
			result.setData(new EmptyJsonResponse());
		} else {
			result.setData(responseData);
		}
		return result;
	}

	public static boolean isNullOrEmpty(Object value) {
		return Objects.isNull(value) || value.toString().isBlank();
	}

	public static boolean isNotNullAndEmpty(Object value) {
		return Objects.nonNull(value) && value.toString().isBlank();
	}

	public static <T> T copyPropertiesIgnoreNull(Object source, T target) {
		return copyPropertiesWithIgnore(source, target, getNullPropertyNames(source));
	}

	public static String[] getNullPropertyNames(Object source, String... ignoreProperties) {
		BeanWrapper src = new BeanWrapperImpl(source);
		PropertyDescriptor[] pds = src.getPropertyDescriptors();

		Set<String> emptyNames = new HashSet<>();
		for (PropertyDescriptor pd : pds) {
			Object srcValue = src.getPropertyValue(pd.getName());
			if (srcValue == null) {
				emptyNames.add(pd.getName());
			}
		}
		if (ignoreProperties != null) {
			Collections.addAll(emptyNames, ignoreProperties);
		}
		String[] result = new String[emptyNames.size()];
		return emptyNames.toArray(result);
	}

	public static <T> T copyPropertiesWithIgnore(Object source, T target, String... ignoreProperties) {
		try {
			BeanUtils.copyProperties(source, target, ignoreProperties);
			return target;
		} catch (Exception e) {
			throw new BusinessException("error in copeing the object");
		}
	}

	public static <T> T copyProperties(Object source, T target) {
		try {
			BeanUtils.copyProperties(source, target);
			return target;
		} catch (Exception e) {
			throw new BusinessException("bean copy error");
		}
	}

	public static String encryptListToSHA1(List<String> inputList, String salt, String algo) {
		Collections.sort(inputList);
		StringBuilder inputString = new StringBuilder();
		inputList.forEach(inputString::append);
		return encryptStringToSHA1(inputString.toString(), algo);
	}

	public static String encryptStringToSHA1(String input, String algo) {
		MessageDigest md;
		try {
			md = MessageDigest.getInstance(algo);
			md.update(input.getBytes(StandardCharsets.ISO_8859_1), 0, input.length());
			byte[] shalhash = md.digest();
			return bytesToHex(shalhash);
		} catch (NoSuchAlgorithmException e) {
			return null;
		}

	}

	public static String bytesToHex(byte[] bytes) {
		if (null == bytes)
			return "";
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < bytes.length; i++) {
			stringBuilder.append(HEX_ARRAY[(bytes[i] >>> 4) & 0x0f]);
			stringBuilder.append(HEX_ARRAY[bytes[i] & 0x0f]);
		}
		return stringBuilder.toString().toLowerCase();
	}

	public static Map<String, String> getQueryParamsMap(String urlString) {
		try {
			if (isNullOrEmpty(urlString)) {
				return Collections.emptyMap();
			}
			String queryPart = "";
			if (urlString.contains("?")) {
				queryPart = urlString.split("\\?(?!\\?)")[1];
			}
			Map<String, String> queryParams = new HashMap<>();

			String[] pairs = queryPart.split("&");
			for (String pair : pairs) {
				String[] keyValuePair = pair.split("=");

				queryParams.put(URLDecoder.decode(keyValuePair[0], StandardCharsets.UTF_8.name()),
						URLDecoder.decode(keyValuePair[1], StandardCharsets.UTF_8.name()));
			}
			return queryParams;
		} catch (Exception e) {
			return Collections.emptyMap();
		}
	}
}

@JsonSerialize
class EmptyJsonResponse {
}