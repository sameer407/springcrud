package com.zkteco.minervaiot.dms.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class DeviceDeleteDTO {
	@ApiModelProperty(name = "siteId", dataType = "String", value = "site Id", example = "47f0aa123456f67f7d963123456200de", position = 1,required = true)
	private String siteId;
}
