package com.zkteco.minervaiot.dms.constants;


import java.text.MessageFormat;
import java.util.Arrays;

/**
 * MQTTConstants
 * 
 * @author howard.liu
 * @date 2021/12/15 15:43
 * @since 1.0.0
 */
public class MQTTConstants {

    public final static String TOPIC_PUBLISH_FORMAT = "cmd/minerva-iot/company-{0}/site-{1}/{2}";

    public final static String PRIORITY_ZERO = "0";
    public final static String PRIORITY_ONE = "1";

    public final static String VERSION_V1 = "1.0.0";



}
