package com.zkteco.minervaiot.dms.awsiot.client;

import com.amazonaws.services.iot.client.AWSIotException;
import com.amazonaws.services.iot.client.AWSIotMqttClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.UUID;

@Slf4j
@Configuration
public class AWSIOTMQTTClient {

    @Value("${amazon.aws.accesskey}")
    public String amazonAWSAccessKey;

    @Value("${amazon.aws.secretkey}")
    public String amazonAWSSecretKey;

    @Value("${amazon.aws.region}")
    public String amazonAWSRegion;

    @Value("${amazon.aws.iotdataendpoint}")
    public String iotDataEndpoint;

    @Bean
    public AWSIotMqttClient initClient() throws AWSIotException {
        AWSIotMqttClient awsIotMqttClient = new AWSIotMqttClient(iotDataEndpoint, UUID.randomUUID().toString(), amazonAWSAccessKey, amazonAWSSecretKey);
        awsIotMqttClient.connect();
        return awsIotMqttClient;
    }
}
