package com.zkteco.minervaiot.dms.util;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.zkteco.minervaiot.dms.dataobject.DeviceDO;

public class CommonSpec extends BasicUtil {

	public static Specification<DeviceDO> getDEviceFilter(String deviceSn, String mac, String productCode, String deviceAlias) {
		return new Specification<DeviceDO>() {
			private static final long serialVersionUID = 1L;

			@Override
			public Predicate toPredicate(Root<DeviceDO> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				List<Predicate> predicates = new ArrayList<>();

				if (!isNullOrEmpty(deviceSn)) {
					predicates.add(criteriaBuilder.equal(root.get("sn"), deviceSn));
				}

				if (!isNullOrEmpty(mac)) {
					predicates.add(criteriaBuilder.equal(root.get("mac"), mac));
				}

				if (!isNullOrEmpty(productCode)) {
					predicates.add(criteriaBuilder.equal(root.get("productCode"), productCode));
				}

				if (!isNullOrEmpty(deviceAlias)) {
					predicates.add(criteriaBuilder.equal(root.get("deviceAlias"), deviceAlias));
				}

				return criteriaBuilder.and(predicates.toArray(new Predicate[0]));

			}
		};
	}

}
