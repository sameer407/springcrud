package com.zkteco.minervaiot.dms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zkteco.minervaiot.dms.service.DeviceSecretnoDO;

public interface DeviceSecretnoRepository extends JpaRepository<DeviceSecretnoDO, String> {
	//
	boolean existsBySn(String sn);

	DeviceSecretnoDO findBySn(String sn);

}
