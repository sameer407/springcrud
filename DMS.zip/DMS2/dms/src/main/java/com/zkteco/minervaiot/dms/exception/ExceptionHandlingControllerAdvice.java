package com.zkteco.minervaiot.dms.exception;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.zkteco.minervaiot.dms.util.BasicUtil;
import com.zkteco.minervaiot.dms.util.ResponseCode;

@ControllerAdvice
public class ExceptionHandlingControllerAdvice extends ResponseEntityExceptionHandler {

	@ExceptionHandler(TokenNotFoundException.class)
	public ResponseEntity<Object> handleTokenNotFoundException(TokenNotFoundException ex) {
		return new ResponseEntity<>(BasicUtil.prepareResponseObject(ResponseCode.DMSE0007, null), HttpStatus.UNAUTHORIZED);
	}

	@ExceptionHandler(InvalidTokenException.class)
	public ResponseEntity<Object> handleInvalidTokenException(InvalidTokenException ex) {
		return new ResponseEntity<>(BasicUtil.prepareResponseObject(ResponseCode.DMSE0008, null), HttpStatus.UNAUTHORIZED);
	}

	@Override
	protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex, HttpHeaders headers,
			HttpStatus httpStatus, WebRequest request) {
		return new ResponseEntity<>(BasicUtil.prepareResponseObject(ResponseCode.DMSE0009, null), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(value = Exception.class)
	public ResponseEntity<Object> handleCustomException(Exception ex, WebRequest request) {
		ex.printStackTrace();
		return new ResponseEntity<>(BasicUtil.prepareResponseObject(ResponseCode.DMSE0010, null), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@Override
	protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex, HttpHeaders headers,
			HttpStatus status, WebRequest request) {
		return new ResponseEntity<>(BasicUtil.prepareResponseObject(ResponseCode.DMSE0011, null), HttpStatus.METHOD_NOT_ALLOWED);
	}

	@ResponseStatus(HttpStatus.UNAUTHORIZED)
	@ExceptionHandler(UnauthorizedException.class)
	public ResponseEntity<Object> handleValidationExceptions(UnauthorizedException ex) {
		return new ResponseEntity<>(BasicUtil.prepareResponseObject(ResponseCode.DMSE0012, null), HttpStatus.UNAUTHORIZED);
	}

}
