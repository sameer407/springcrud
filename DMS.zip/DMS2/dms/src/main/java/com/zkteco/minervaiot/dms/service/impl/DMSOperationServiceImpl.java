//package com.zkteco.minervaiot.dms.service.impl;
//
//import java.util.HashMap;
//import java.util.Map;
//
//import org.json.JSONObject;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.http.HttpEntity;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.HttpMethod;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.MediaType;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Service;
//import org.springframework.web.client.RestTemplate;
//import org.springframework.web.util.UriComponentsBuilder;
//
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.zkteco.minervaiot.dms.config.MessageConfig;
//import com.zkteco.minervaiot.dms.service.DMSOperationService;
//import com.zkteco.minervaiot.dms.util.ResultEntity;
//
//@Service
//public class DMSOperationServiceImpl implements DMSOperationService {
//
//	@Value("${dbs.url}")
//	private String baseUrl;
//
//	@Value("${dbs.url.getToken}")
//	private String getToken;
//
//	@Value("${dbs.url.addDevice}")
//	private String addDeviceUrl;
//
//	@Value("${dbs.url.modifyDevice}")
//	private String modifyDeviceUrl;
//
//	@Value("${dbs.url.deleteDevice}")
//	private String deleteDeviceUrl;
//
//	@Value("${dbs.url.enableDevice}")
//	private String enableDeviceUrl;
//
//	@Value("${dbs.url.disableDevice}")
//	private String disableDeviceUrl;
//
//	@Value("${dbs.url.restartDevice}")
//	private String restartDevice;
//
//	@Value("${dbs.url.queryDeviceInfo}")
//	private String queryDeviceInfo;
//
//	@Value("${dbs.url.reuploadAttendance}")
//	private String uploadAttRecord;
//
//	@Value("${dbs.url.reuploadPersonnel}")
//	private String uploadPersonRecord;
//
//	@Value("${dbs.url.registerBiometrics}")
//	private String registerBiometrics;
//
//	@Value("${dbs.url.cancleRegister}")
//	private String cancleBiometrics;
//
//	@Value("${dbs.url.queryDeviceCommand}")
//	private String queryCommandDevice;
//
//	@Autowired
//	private ObjectMapper objMap;
//
//	@Autowired
//	RestTemplate restTemplate;
//
//	private String tokenExpire;
//
//	private String accessToken;
//
//	@Autowired
//	private MessageConfig message;
//
//	@Override
//	public ResponseEntity<ResultEntity> addDevice(String jsonStr) {
//		ResultEntity res = new ResultEntity();
//		try {
//			HttpHeaders headers = new HttpHeaders();
//			Map<String, Object> requestBody = new HashMap<>();
//			Map<String, Map> payload = new HashMap<>();
//			Map<String, String> params = new HashMap<String, String>();
//			JSONObject json = JSONObject.parseObject(jsonStr);
//
//			String sn = json.getString("sn");
//			String timezone = json.getString("timezone");
//			String alias = json.getString("alias");
//
//			if (accessToken != null && StringUtils.isNotBlank(accessToken)) {
//				headers.set("Authorization", accessToken);
//				headers.setContentType(MediaType.APPLICATION_JSON);
//				params.put("sn", sn);
//				params.put("timezone", timezone);
//				params.put("alias", alias);
//				payload.put("params", params);
//				requestBody.put("lang", "en");
//				requestBody.put("payload", payload);
//				String reqBody = objMap.writeValueAsString(requestBody);
//				HttpEntity<String> entity = new HttpEntity<>(reqBody, headers);
//				String response = restTemplate.exchange(baseUrl + addDeviceUrl, HttpMethod.POST, entity, String.class)
//						.getBody();
//				JSONObject responseJSON = JSONObject.parseObject(response);
//				res.setCode("00000000");
//				res.setMsg(message.locale("00000000"));
//				res.setData(responseJSON.get("payload"));
//			} else {
//				getAccessToken();
//				addDevice(jsonStr);
//			}
//		} catch (Exception ex) {
//			res.setCode("DOSE0001");
//			res.setMsg(message.locale("DOSE0001"));
//			res.setData(ex.getMessage());
//		}
//		return new ResponseEntity<ResultEntity>(res, HttpStatus.OK);
//	}
//
//	@Override
//	public ResponseEntity<ResultEntity> modifyDevice(String jsonStr) {
//		ResultEntity res = new ResultEntity();
//		try {
//			HttpHeaders headers = new HttpHeaders();
//			Map<String, Object> requestBody = new HashMap<>();
//			Map<String, Map> payload = new HashMap<>();
//			Map<String, String> params = new HashMap<String, String>();
//			JSONObject json = JSONObject.parseObject(jsonStr);
//
//			String sn = json.getString("sn");
//			String timezone = json.getString("timezone");
//			String alias = json.getString("alias");
//
//			if (accessToken != null && StringUtils.isNotBlank(accessToken)) {
//				headers.set("Authorization", accessToken);
//				headers.setContentType(MediaType.APPLICATION_JSON);
//				params.put("sn", sn);
//				params.put("timezone", timezone);
//				params.put("alias", alias);
//				payload.put("params", params);
//				requestBody.put("lang", "en");
//				requestBody.put("payload", payload);
//				String reqBody = objMap.writeValueAsString(requestBody);
//				HttpEntity<String> entity = new HttpEntity<>(reqBody, headers);
//				String response = restTemplate
//						.exchange(baseUrl + modifyDeviceUrl, HttpMethod.POST, entity, String.class).getBody();
//				JSONObject responseJSON = JSONObject.parseObject(response);
//				res.setCode("00000000");
//				res.setMsg(message.locale("00000000"));
//				res.setData(responseJSON.get("payload"));
//			} else {
//				getAccessToken();
//				modifyDevice(jsonStr);
//			}
//		} catch (Exception ex) {
//			res.setCode("DOSE0002");
//			res.setMsg(message.locale("DOSE0002"));
//			res.setData(ex.getMessage());
//		}
//		return new ResponseEntity<ResultEntity>(res, HttpStatus.OK);
//	}
//
//	@Override
//	public ResponseEntity<ResultEntity> deleteDevice(String jsonStr) {
//		ResultEntity res = new ResultEntity();
//		try {
//			HttpHeaders headers = new HttpHeaders();
//			Map<String, Object> requestBody = new HashMap<>();
//			Map<String, Map> payload = new HashMap<>();
//			Map<String, String> params = new HashMap<String, String>();
//			JSONObject json = JSONObject.parseObject(jsonStr);
//
//			String sn = json.getString("sn");
//
//			if (accessToken != null && StringUtils.isNotBlank(accessToken)) {
//				headers.set("Authorization", accessToken);
//				headers.setContentType(MediaType.APPLICATION_JSON);
//				params.put("sn", sn);
//				payload.put("params", params);
//				requestBody.put("lang", "en");
//				requestBody.put("payload", payload);
//				String reqBody = objMap.writeValueAsString(requestBody);
//				HttpEntity<String> entity = new HttpEntity<>(reqBody, headers);
//				String response = restTemplate
//						.exchange(baseUrl + deleteDeviceUrl, HttpMethod.POST, entity, String.class).getBody();
//				JSONObject responseJSON = JSONObject.parseObject(response);
//				res.setCode("00000000");
//				res.setMsg(message.locale("00000000"));
//				res.setData(responseJSON.get("payload"));
//			} else {
//				getAccessToken();
//				deleteDevice(jsonStr);
//			}
//		} catch (Exception ex) {
//			res.setCode("DOSE0003");
//			res.setMsg(message.locale("DOSE0003"));
//			res.setData(ex.getMessage());
//		}
//		return new ResponseEntity<ResultEntity>(res, HttpStatus.OK);
//	}
//
//	@Override
//	public ResponseEntity<ResultEntity> queryDeviceInfo(String jsonStr) {
//		ResultEntity res = new ResultEntity();
//		try {
//			HttpHeaders headers = new HttpHeaders();
//			Map<String, Object> requestBody = new HashMap<>();
//			Map<String, Map> payload = new HashMap<>();
//			Map<String, Object> params = new HashMap<String, Object>();
//			JSONObject json = JSONObject.parseObject(jsonStr);
//
//			String sn = json.getString("sn");
//			int needDetails = Integer.parseInt(json.get("needDetails").toString());
//
//			if (accessToken != null && StringUtils.isNotBlank(accessToken)) {
//				headers.set("Authorization", accessToken);
//				headers.setContentType(MediaType.APPLICATION_JSON);
//				params.put("sn", sn);
//				params.put("needDetails", needDetails);
//				payload.put("params", params);
//				requestBody.put("lang", "en");
//				requestBody.put("payload", payload);
//				String reqBody = objMap.writeValueAsString(requestBody);
//				HttpEntity<String> entity = new HttpEntity<>(reqBody, headers);
//				String response = restTemplate
//						.exchange(baseUrl + queryDeviceInfo, HttpMethod.POST, entity, String.class).getBody();
//				JSONObject responseJSON = JSONObject.parseObject(response);
//				res.setCode("00000000");
//				res.setMsg(message.locale("00000000"));
//				res.setData(responseJSON.get("payload"));
//			} else {
//				getAccessToken();
//				queryDeviceInfo(jsonStr);
//			}
//		} catch (Exception ex) {
//			res.setCode("DOSE0011");
//			res.setMsg(message.locale("DOSE0011"));
//			res.setData(ex.getMessage());
//		}
//		return new ResponseEntity<ResultEntity>(res, HttpStatus.OK);
//	}
//
//	@Override
//	public ResponseEntity<ResultEntity> enableDevice(String jsonStr) {
//		ResultEntity res = new ResultEntity();
//		try {
//			HttpHeaders headers = new HttpHeaders();
//			Map<String, Object> requestBody = new HashMap<>();
//			Map<String, Map> payload = new HashMap<>();
//			Map<String, String> params = new HashMap<String, String>();
//			JSONObject json = JSONObject.parseObject(jsonStr);
//
//			String sn = json.getString("sn");
//
//			if (accessToken != null && StringUtils.isNotBlank(accessToken)) {
//				headers.set("Authorization", accessToken);
//				headers.setContentType(MediaType.APPLICATION_JSON);
//				params.put("sn", sn);
//				payload.put("params", params);
//				requestBody.put("lang", "en");
//				requestBody.put("payload", payload);
//				String reqBody = objMap.writeValueAsString(requestBody);
//				HttpEntity<String> entity = new HttpEntity<>(reqBody, headers);
//				String response = restTemplate
//						.exchange(baseUrl + enableDeviceUrl, HttpMethod.POST, entity, String.class).getBody();
//				JSONObject responseJSON = JSONObject.parseObject(response);
//				res.setCode("00000000");
//				res.setMsg(message.locale("00000000"));
//				res.setData(responseJSON.get("payload"));
//			} else {
//				getAccessToken();
//				enableDevice(jsonStr);
//			}
//		} catch (Exception ex) {
//			res.setCode("DOSE0005");
//			res.setMsg(message.locale("DOSE0005"));
//			res.setData(ex.getMessage());
//		}
//		return new ResponseEntity<ResultEntity>(res, HttpStatus.OK);
//	}
//
//	@Override
//	public ResponseEntity<ResultEntity> disableDevice(String jsonStr) {
//		ResultEntity res = new ResultEntity();
//		try {
//			HttpHeaders headers = new HttpHeaders();
//			Map<String, Object> requestBody = new HashMap<>();
//			Map<String, Map> payload = new HashMap<>();
//			Map<String, String> params = new HashMap<String, String>();
//			JSONObject json = JSONObject.parseObject(jsonStr);
//
//			String sn = json.getString("sn");
//
//			if (accessToken != null && StringUtils.isNotBlank(accessToken)) {
//				headers.set("Authorization", accessToken);
//				headers.setContentType(MediaType.APPLICATION_JSON);
//				params.put("sn", sn);
//				payload.put("params", params);
//				requestBody.put("lang", "en");
//				requestBody.put("payload", payload);
//				String reqBody = objMap.writeValueAsString(requestBody);
//				HttpEntity<String> entity = new HttpEntity<>(reqBody, headers);
//				String response = restTemplate
//						.exchange(baseUrl + disableDeviceUrl, HttpMethod.POST, entity, String.class).getBody();
//				JSONObject responseJSON = JSONObject.parseObject(response);
//				res.setCode("00000000");
//				res.setMsg(message.locale("00000000"));
//				res.setData(responseJSON.get("payload"));
//			} else {
//				getAccessToken();
//				disableDevice(jsonStr);
//			}
//		} catch (Exception ex) {
//			res.setCode("DOSE0006");
//			res.setMsg(message.locale("DOSE0006"));
//			res.setData(ex.getMessage());
//		}
//		return new ResponseEntity<ResultEntity>(res, HttpStatus.OK);
//	}
//
//	@Override
//	public ResponseEntity<ResultEntity> rebootDevice(String jsonStr) {
//		ResultEntity res = new ResultEntity();
//		try {
//			HttpHeaders headers = new HttpHeaders();
//			Map<String, Object> requestBody = new HashMap<>();
//			Map<String, Map> payload = new HashMap<>();
//			Map<String, String> params = new HashMap<String, String>();
//			JSONObject json = JSONObject.parseObject(jsonStr);
//
//			String sn = json.getString("sn");
//
//			if (accessToken != null && StringUtils.isNotBlank(accessToken)) {
//				headers.set("Authorization", accessToken);
//				headers.setContentType(MediaType.APPLICATION_JSON);
//				params.put("sn", sn);
//				payload.put("params", params);
//				requestBody.put("lang", "en");
//				requestBody.put("payload", payload);
//				String reqBody = objMap.writeValueAsString(requestBody);
//				HttpEntity<String> entity = new HttpEntity<>(reqBody, headers);
//				String response = restTemplate.exchange(baseUrl + restartDevice, HttpMethod.POST, entity, String.class)
//						.getBody();
//				JSONObject responseJSON = JSONObject.parseObject(response);
//				res.setCode("00000000");
//				res.setMsg(message.locale("00000000"));
//				res.setData(responseJSON.get("payload"));
//			} else {
//				getAccessToken();
//				rebootDevice(jsonStr);
//			}
//		} catch (Exception ex) {
//			res.setCode("DOSE0004");
//			res.setMsg(message.locale("DOSE0004"));
//			res.setData(ex.getMessage());
//		}
//		return new ResponseEntity<ResultEntity>(res, HttpStatus.OK);
//	}
//
//	@Override
//	public ResponseEntity<ResultEntity> uploadAttRecord(String jsonStr) {
//		ResultEntity res = new ResultEntity();
//		try {
//			HttpHeaders headers = new HttpHeaders();
//			Map<String, Object> requestBody = new HashMap<>();
//			Map<String, Map> payload = new HashMap<>();
//			Map<String, Object> params = new HashMap<String, Object>();
//			JSONObject json = JSONObject.parseObject(jsonStr);
//
//			String sn = json.getString("sn");
//			Long startTime = json.getLongValue("startTime");
//			Long endTime = json.getLongValue("endTime");
//			String onlineCheck = json.getString("onlineCheck");
//
//			if (accessToken != null && StringUtils.isNotBlank(accessToken)) {
//				headers.set("Authorization", accessToken);
//				headers.setContentType(MediaType.APPLICATION_JSON);
//				params.put("sn", sn);
//				params.put("startTime", startTime);
//				params.put("endTime", endTime);
//				params.put("onlineCheck", onlineCheck);
//				payload.put("params", params);
//				requestBody.put("lang", "en");
//				requestBody.put("payload", payload);
//				String reqBody = objMap.writeValueAsString(requestBody);
//				HttpEntity<String> entity = new HttpEntity<>(reqBody, headers);
//				String response = restTemplate
//						.exchange(baseUrl + uploadAttRecord, HttpMethod.POST, entity, String.class).getBody();
//				JSONObject responseJSON = JSONObject.parseObject(response);
//				res.setCode("00000000");
//				res.setMsg(message.locale("00000000"));
//				res.setData(responseJSON.get("payload"));
//			} else {
//				getAccessToken();
//				uploadAttRecord(jsonStr);
//			}
//		} catch (Exception ex) {
//			res.setCode("DOSE0007");
//			res.setMsg(message.locale("DOSE0007"));
//			res.setData(ex.getMessage());
//		}
//		return new ResponseEntity<ResultEntity>(res, HttpStatus.OK);
//	}
//
//	@Override
//	public ResponseEntity<ResultEntity> uploadPersonRecord(String jsonStr) {
//		ResultEntity res = new ResultEntity();
//		try {
//			HttpHeaders headers = new HttpHeaders();
//			Map<String, Object> requestBody = new HashMap<>();
//			Map<String, Map> payload = new HashMap<>();
//			Map<String, String> params = new HashMap<String, String>();
//			JSONObject json = JSONObject.parseObject(jsonStr);
//
//			String sn = json.getString("sn");
//			String onlineCheck = json.getString("onlineCheck");
//
//			if (accessToken != null && StringUtils.isNotBlank(accessToken)) {
//				headers.set("Authorization", accessToken);
//				headers.setContentType(MediaType.APPLICATION_JSON);
//				params.put("sn", sn);
//				params.put("onlineCheck", onlineCheck);
//				payload.put("params", params);
//				requestBody.put("lang", "en");
//				requestBody.put("payload", payload);
//				String reqBody = objMap.writeValueAsString(requestBody);
//				HttpEntity<String> entity = new HttpEntity<>(reqBody, headers);
//				String response = restTemplate
//						.exchange(baseUrl + uploadPersonRecord, HttpMethod.POST, entity, String.class).getBody();
//				JSONObject responseJSON = JSONObject.parseObject(response);
//				res.setCode("00000000");
//				res.setMsg(message.locale("00000000"));
//				res.setData(responseJSON.get("payload"));
//			} else {
//				getAccessToken();
//				uploadPersonRecord(jsonStr);
//			}
//		} catch (Exception ex) {
//			res.setCode("DOSE0008");
//			res.setMsg(message.locale("DOSE0008"));
//			res.setData(ex.getMessage());
//		}
//		return new ResponseEntity<ResultEntity>(res, HttpStatus.OK);
//	}
//
//	@Override
//	public ResponseEntity<ResultEntity> registerBiometrics(String jsonStr) {
//		ResultEntity res = new ResultEntity();
//		try {
//			HttpHeaders headers = new HttpHeaders();
//			Map<String, Object> requestBody = new HashMap<>();
//			Map<String, Map> payload = new HashMap<>();
//			Map<String, String> params = new HashMap<String, String>();
//			JSONObject json = JSONObject.parseObject(jsonStr);
//
//			String sn = json.getString("sn");
//			String pin = json.getString("pin");
//			String type = json.getString("type");
//			String no = json.getString("no");
//			String isCover = json.getString("isCover");
//
//			if (accessToken != null && StringUtils.isNotBlank(accessToken)) {
//				headers.set("Authorization", accessToken);
//				headers.setContentType(MediaType.APPLICATION_JSON);
//				params.put("sn", sn);
//				params.put("pin", pin);
//				params.put("type", type);
//				params.put("no", no);
//				params.put("isCover", isCover);
//				payload.put("params", params);
//				requestBody.put("lang", "en");
//				requestBody.put("payload", payload);
//				String reqBody = objMap.writeValueAsString(requestBody);
//				HttpEntity<String> entity = new HttpEntity<>(reqBody, headers);
//				String response = restTemplate
//						.exchange(baseUrl + registerBiometrics, HttpMethod.POST, entity, String.class).getBody();
//				JSONObject responseJSON = JSONObject.parseObject(response);
//				res.setCode("00000000");
//				res.setMsg(message.locale("00000000"));
//				res.setData(responseJSON.get("payload"));
//			} else {
//				getAccessToken();
//				registerBiometrics(jsonStr);
//			}
//		} catch (Exception ex) {
//			res.setCode("DOSE0009");
//			res.setMsg(message.locale("DOSE0009"));
//			res.setData(ex.getMessage());
//		}
//		return new ResponseEntity<ResultEntity>(res, HttpStatus.OK);
//	}
//
//	@Override
//	public ResponseEntity<ResultEntity> cancelBiometrics(String jsonStr) {
//		ResultEntity res = new ResultEntity();
//		try {
//			HttpHeaders headers = new HttpHeaders();
//			Map<String, Object> requestBody = new HashMap<>();
//			Map<String, Map> payload = new HashMap<>();
//			Map<String, String> params = new HashMap<String, String>();
//			JSONObject json = JSONObject.parseObject(jsonStr);
//
//			String sn = json.getString("sn");
//
//			if (accessToken != null && StringUtils.isNotBlank(accessToken)) {
//				headers.set("Authorization", accessToken);
//				headers.setContentType(MediaType.APPLICATION_JSON);
//				params.put("sn", sn);
//				payload.put("params", params);
//				requestBody.put("lang", "en");
//				requestBody.put("payload", payload);
//				String reqBody = objMap.writeValueAsString(requestBody);
//				HttpEntity<String> entity = new HttpEntity<>(reqBody, headers);
//				String response = restTemplate
//						.exchange(baseUrl + cancleBiometrics, HttpMethod.POST, entity, String.class).getBody();
//				JSONObject responseJSON = JSONObject.parseObject(response);
//				res.setCode("00000000");
//				res.setMsg(message.locale("00000000"));
//				res.setData(responseJSON.get("payload"));
//			} else {
//				getAccessToken();
//				cancelBiometrics(jsonStr);
//			}
//		} catch (Exception ex) {
//			res.setCode("DOSE0010");
//			res.setMsg(message.locale("DOSE0010"));
//			res.setData(ex.getMessage());
//		}
//		return new ResponseEntity<ResultEntity>(res, HttpStatus.OK);
//	}
//
//	@Override
//	public ResponseEntity<ResultEntity> queryDeviceCommand(String jsonStr) {
//		ResultEntity res = new ResultEntity();
//		try {
//			HttpHeaders headers = new HttpHeaders();
//			Map<String, Object> requestBody = new HashMap<>();
//			Map<String, Object> payload = new HashMap<>();
//			Map<String, Object> params = new HashMap<String, Object>();
//			JSONObject json = JSONObject.parseObject(jsonStr);
//
//			int curPage = Integer.parseInt(json.get("sn").toString());
//			int pageSize = Integer.parseInt(json.get("pageSize").toString());
//
//			String sn = json.getString("sn");
//			Long startTime = json.getLongValue("startTime");
//			Long endTime = json.getLongValue("endTime");
//			String status = json.getString("status");
//
//			if (accessToken != null && StringUtils.isNotBlank(accessToken)) {
//				headers.set("Authorization", accessToken);
//				headers.setContentType(MediaType.APPLICATION_JSON);
//				params.put("sn", sn);
//				params.put("startTime", startTime);
//				params.put("endTime", endTime);
//				params.put("status", status);
//				payload.put("params", params);
//				payload.put("curPage", curPage);
//				payload.put("pageSize", pageSize);
//				requestBody.put("lang", "en");
//				requestBody.put("payload", payload);
//				String reqBody = objMap.writeValueAsString(requestBody);
//				HttpEntity<String> entity = new HttpEntity<>(reqBody, headers);
//				String response = restTemplate
//						.exchange(baseUrl + queryCommandDevice, HttpMethod.POST, entity, String.class).getBody();
//				JSONObject responseJSON = JSONObject.parseObject(response);
//				res.setCode("00000000");
//				res.setMsg(message.locale("00000000"));
//				res.setData(responseJSON.get("payload"));
//			} else {
//				getAccessToken();
//				queryDeviceCommand(jsonStr);
//			}
//		} catch (Exception ex) {
//			res.setCode("DOSE0012");
//			res.setMsg(message.locale("DOSE0012"));
//			res.setData(ex.getMessage());
//		}
//		return new ResponseEntity<ResultEntity>(res, HttpStatus.OK);
//	}
//
//	public void getAccessToken() {
//		try {
//			String code = "";
//			HttpHeaders headers = new HttpHeaders();
//			headers.set("", "");
//			HttpEntity<String> entity = new HttpEntity<>(headers);
//
//			Map<String, String> urlParams = new HashMap<>();
//
//			UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(baseUrl + getToken)
//					.queryParam("appKey", "11d98b6a096c429cbde5c7c5c58c5655").queryParam("timestamp", "1529223702")
//					.queryParam("sign", "f767723c1c017cd0b29ec3953d1c4da9");
//
//			String response = restTemplate.exchange(builder.build().toUri(), HttpMethod.POST, entity, String.class)
//					.getBody();
//			JSONObject json = JSONObject.parseObject(response);
//			code = json.getString("code");
//
//			accessToken = json.get("accessToken").toString();
//			tokenExpire = json.get("expiresIn").toString();
//		} catch (Exception ex) {
//			ex.printStackTrace();
//		}
//
//	}
//
//}
