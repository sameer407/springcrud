package com.zkteco.minervaiot.dms.dto;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * vo model conversion top-level parent class
 * 
 * @author: <a href:"mailto:max.zheng@zkteco.com">max</a>
 * @date: 2017-12-06 09:56:26
 */
@Data
public abstract class BaseDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String companyId;

	private Date createdAt;

	private Date updateAt;

	/** Is it the only query */
	protected Boolean equals = false;

	public BaseDTO() {
		super();
	}

	public BaseDTO(Boolean equals) {
		super();
		this.equals = equals;
	}

	public Boolean getEquals() {
		return equals;
	}

	public void setEquals(Boolean equals) {
		this.equals = equals;
	}

}
