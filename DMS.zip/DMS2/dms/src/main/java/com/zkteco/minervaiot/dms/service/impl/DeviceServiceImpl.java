package com.zkteco.minervaiot.dms.service.impl;

import com.amazonaws.services.iot.AWSIot;
import com.amazonaws.services.iot.model.*;
import com.amazonaws.services.iotdata.AWSIotData;
import com.amazonaws.services.iotdata.model.DeleteThingShadowRequest;
import com.zkteco.minervaiot.dms.dataobject.DeviceDO;
import com.zkteco.minervaiot.dms.dto.*;
import com.zkteco.minervaiot.dms.repository.DeviceRepository;
import com.zkteco.minervaiot.dms.repository.DeviceSecretnoRepository;
import com.zkteco.minervaiot.dms.service.AWSIOTService;
import com.zkteco.minervaiot.dms.service.CmdService;
import com.zkteco.minervaiot.dms.service.DeviceSecretnoDO;
import com.zkteco.minervaiot.dms.service.DeviceService;
import com.zkteco.minervaiot.dms.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.*;

@Service
public class DeviceServiceImpl implements DeviceService {

	@Autowired
	DeviceSecretnoRepository secretnoRepository;

	@Autowired
	DeviceRepository deviceRepository;

	@Autowired
	AWSIot awsIot;

	@Autowired
	AWSIotData awsIotData;

	@Autowired
	AWSIOTService awsIOTService;

	@Autowired
	private TokenUtil tokenUtil;

	@Autowired
	private CmdService cmdService;

	public static final String SUCCESS = "success";
	public static final String SUCCESS_COUNT = "successCount";
	public static final String ERROR = "error";
	public static final String ERROR_COUNT = "errorCount";
	public static final String DEVICE = "devices";
	public static final String REQUEST_DATA_COUNT = "total data in a request";

	@Override
	public Result getDeviceSecretNo(String deviceSn) {
		if (BasicUtil.isNullOrEmpty(deviceSn)) {
			return BasicUtil.prepareResponseObject(ResponseCode.DMSE0001, null);
		}
		DeviceSecretnoDO secretnumberDO = secretnoRepository.findBySn(deviceSn);
		if (BasicUtil.isNullOrEmpty(secretnumberDO)) {
			return BasicUtil.prepareResponseObject(ResponseCode.DMSE0003, null);
		}
		Map<String, String> reponse = new LinkedHashMap<>();
		reponse.put("sn", secretnumberDO.getSn());
		reponse.put("secretNo", secretnumberDO.getSecretNo());
		return BasicUtil.prepareResponseObject(ResponseCode.DMSI0000, reponse);
	}

	@Override
	public Result saveDeviceSecretNo(String deviceSn) {
		if (BasicUtil.isNullOrEmpty(deviceSn)) {
			return BasicUtil.prepareResponseObject(ResponseCode.DMSE0001, null);
		}

		if (secretnoRepository.existsBySn(deviceSn)) {
			return BasicUtil.prepareResponseObject(ResponseCode.DMSE0002, null);
		}
		DeviceSecretnoDO devicesecretNo = new DeviceSecretnoDO();
		devicesecretNo.setSn(deviceSn);
		devicesecretNo.setSecretNo(BasicUtil.encryptStringToSHA1(deviceSn, BasicUtil.ENCRYPT_ALGO_SHA1));
		secretnoRepository.save(devicesecretNo);
		Map<String, String> reponse = new LinkedHashMap<>();
		reponse.put("sn", devicesecretNo.getSn());
		reponse.put("secretNo", devicesecretNo.getSecretNo());
		return BasicUtil.prepareResponseObject(ResponseCode.DMSI0003, reponse);
	}

	@Override
	public Result createDevices(DeviceDTO deviceDTO) {
		DeviceDO deviceDo = deviceRepository.findBySn(deviceDTO.getSn());
		if (!BasicUtil.isNullOrEmpty(deviceDo)) {
			BasicUtil.copyPropertiesIgnoreNull(deviceDTO, deviceDo);
			deviceDo.setUpdatedAt(new Date());
			deviceRepository.save(deviceDo);
			Map<String, String> responseMap = new LinkedHashMap<>();
			responseMap.put("id", deviceDo.getId());
			responseMap.put("sn", deviceDo.getSn());
			return BasicUtil.prepareResponseObject(ResponseCode.DMSI0002, responseMap);
		}

		DeviceDO deviceDO = new DeviceDO();
		BasicUtil.copyPropertiesIgnoreNull(deviceDTO, deviceDO);
		deviceRepository.save(deviceDO);
		Map<String, String> responseMap = new LinkedHashMap<>();
		responseMap.put("id", deviceDO.getId());
		responseMap.put("sn", deviceDO.getSn());
		return BasicUtil.prepareResponseObject(ResponseCode.DMSI0001, responseMap);
	}

	@Override
	public Result updateDevices(String sn, DeviceDTO deviceDTO) {
		DeviceDO deviceDo = deviceRepository.findBySn(sn);

		if (BasicUtil.isNullOrEmpty(deviceDo)) {
			return BasicUtil.prepareResponseObject(ResponseCode.DMSE0003, null);
		}

		DeviceDO duplicateSn = deviceRepository.findBySnIgnoreCaseAndIdNot(deviceDTO.getSn(), deviceDo.getId());

		if (!BasicUtil.isNullOrEmpty(duplicateSn)) {
			return BasicUtil.prepareResponseObject(ResponseCode.DMSE0002, null);
		}

		BasicUtil.copyPropertiesIgnoreNull(deviceDTO, deviceDo);
		deviceDo.setUpdatedAt(new Date());

		deviceRepository.save(deviceDo);

		Map<String, String> responseMap = new LinkedHashMap<>();
		responseMap.put("id", deviceDo.getId());
		responseMap.put("sn", deviceDo.getSn());

		return BasicUtil.prepareResponseObject(ResponseCode.DMSI0002, responseMap);
	}

	@Override
	public Result findByfilter(int pageNumber, int pageSize, String deviceSn, String mac, String productCode, String deviceAlias) {
		if (pageNumber == 0) {
			pageNumber = 1;
		}
		if (pageSize == 0) {
			pageSize = 10;
		}
		Pageable paging = PageRequest.of(pageNumber - 1, pageSize);
		Page<DeviceDO> deviceDOPage = deviceRepository.findAll(CommonSpec.getDEviceFilter(deviceSn, mac, productCode, deviceAlias),
				paging);
		if (deviceDOPage.getContent().isEmpty()) {
			return BasicUtil.prepareResponseObject(ResponseCode.DMSE0004, null);
		}
		List<DeviceDTO> deviceList = new ArrayList<>();

		for (DeviceDO deviceDO : deviceDOPage.getContent()) {
			DeviceDTO deviceDto = new DeviceDTO();
			BasicUtil.copyProperties(deviceDO, deviceDto);
			deviceList.add(deviceDto);
		}

		Map<String, Object> responseData = new LinkedHashMap<>();
		responseData.put("totalCount", deviceDOPage.getTotalElements());
		responseData.put("currentPage", pageNumber);
		responseData.put("totalPages", deviceDOPage.getTotalPages());
		responseData.put("devices", deviceList);
		return BasicUtil.prepareResponseObject(ResponseCode.DMSI0000, responseData);
	}

	@Override
	public Result addOrUpdateDevice(List<DeviceDTO> deviceDTO) {
		Map<String, Object> responseData = new LinkedHashMap<>();
		Map<String, String> responseMap = null;
		List<Result> successList = new ArrayList<>();
		List<Result> errorList = new ArrayList<>();

		if (deviceDTO.size() >= 1000) {
			return BasicUtil.prepareResponseObject(ResponseCode.DMSE0005, null);
		}

		for (DeviceDTO device : deviceDTO) {
			Result errors = isValidToUpdate(device);
			if (!BasicUtil.isNullOrEmpty(errors)) {
				errorList.add(errors);
			} else {

				DeviceDO deviceDo = deviceRepository.findBySn(device.getSn());
				if (!BasicUtil.isNullOrEmpty(deviceDo)) {

					BasicUtil.copyPropertiesIgnoreNull(device, deviceDo);
					deviceDo.setUpdatedAt(new Date());
					deviceRepository.save(deviceDo);
					responseMap = new LinkedHashMap<>();
					responseMap.put("id", deviceDo.getId());
					responseMap.put("sn", deviceDo.getSn());
					successList.add(BasicUtil.prepareResponseObject(ResponseCode.DMSI0002, responseMap));
				} else {

					DeviceDO deviceDO = new DeviceDO();
					BasicUtil.copyPropertiesIgnoreNull(device, deviceDO);
					deviceRepository.save(deviceDO);
					responseMap = new LinkedHashMap<>();
					responseMap.put("id", deviceDO.getId());
					responseMap.put("sn", deviceDO.getSn());
					successList.add(BasicUtil.prepareResponseObject(ResponseCode.DMSI0001, responseMap));
				}
			}
		}

		responseData.put(REQUEST_DATA_COUNT, deviceDTO.size());
		responseData.put(SUCCESS_COUNT, successList.size());
		responseData.put(DEVICE, successList);
		responseData.put(ERROR_COUNT, errorList.size());
		responseData.put(ERROR, errorList);

		if (!errorList.isEmpty())
			return BasicUtil.prepareResponseObject(ResponseCode.DMSW0000, responseData);

		return BasicUtil.prepareResponseObject(ResponseCode.DMSI0000, responseData);
	}

	@Override
	public Result getDeviceBindCompany(String deviceSn){
		if (BasicUtil.isNullOrEmpty(deviceSn)) {
			return BasicUtil.prepareResponseObject(ResponseCode.DMSE0001, null);
		}
		DeviceDO deviceDO = deviceRepository.findBySn(deviceSn);
		if (BasicUtil.isNullOrEmpty(deviceDO)) {
			return BasicUtil.prepareResponseObject(ResponseCode.DMSE0003, null);
		}
		if(StringUtils.isEmpty(deviceDO.getCompanyId())){
			return BasicUtil.prepareResponseObject(ResponseCode.DMSE0013, null);
		}
		Map<String, Object> response = new LinkedHashMap<>();
		response.put("device",deviceDO);
		return BasicUtil.prepareResponseObject(ResponseCode.DMSI0000, response);
	}

	private Result isValidToUpdate(DeviceDTO device) {
		if (!BasicUtil.isNullOrEmpty(device.getPhoto()) && !device.getPhoto().contains("https://")) {
			return BasicUtil.prepareResponseObject(ResponseCode.DMSE0006, null);
		}
		return null;
	}

	@Override
	public Result deleteDevice(String sn, DeviceDeleteDTO deviceDeleteDTO) {
		TokenResponseDTO tokenData = tokenUtil.getTokenData();

		String siteId = deviceDeleteDTO.getSiteId();
		if(BasicUtil.isNullOrEmpty(siteId)){
			return BasicUtil.prepareResponseObject(ResponseCode.DMSE0015, null);
		}

		DeviceDO deviceDo = deviceRepository.findBySn(sn);
		if (BasicUtil.isNullOrEmpty(deviceDo)) {
			return BasicUtil.prepareResponseObject(ResponseCode.DMSE0003, null);
		}

		if(BasicUtil.isNullOrEmpty(deviceDo.getCompanyCode()) || BasicUtil.isNullOrEmpty(deviceDo.getCompanyId()) || !deviceDo.getCompanyCode().equals(tokenData.getCompanyCode())){
			return BasicUtil.prepareResponseObject(ResponseCode.DMSE0012, null);
		}

		String certificateArn = deviceDo.getDevCertificate();

		if(!BasicUtil.isNullOrEmpty(certificateArn)){

			//send  delete device command
			cmdService.issueDeleteDeviceCommand(new Command(tokenData.getCompanyId(),deviceDeleteDTO.getSiteId(),sn));

			//detach policy for certificate
			DetachPolicyRequest detachPolicyRequest = new DetachPolicyRequest();
			detachPolicyRequest.setPolicyName(sn);
			detachPolicyRequest.setTarget(certificateArn);
			awsIot.detachPolicy(detachPolicyRequest);

			//detach thing for certificate
			DetachThingPrincipalRequest detachThingPrincipalRequest = new DetachThingPrincipalRequest();
			detachThingPrincipalRequest.setThingName(sn);
			detachThingPrincipalRequest.setPrincipal(certificateArn);
			awsIot.detachThingPrincipal(detachThingPrincipalRequest);

			// update certificate is  inactive
			String certificateId = certificateArn.split("/")[1];
			UpdateCertificateRequest updateCertificateRequest = new UpdateCertificateRequest();
			updateCertificateRequest.setCertificateId(certificateId);
			updateCertificateRequest.setNewStatus("INACTIVE");
			awsIot.updateCertificate(updateCertificateRequest);

			// delete certificate
			DeleteCertificateRequest deleteCertificateRequest = new DeleteCertificateRequest();
			deleteCertificateRequest.setCertificateId(certificateId);
			deleteCertificateRequest.setForceDelete(false);
			awsIot.deleteCertificate(deleteCertificateRequest);

			//delete policy
			DeletePolicyRequest deletePolicyRequest = new DeletePolicyRequest();
			deletePolicyRequest.setPolicyName(sn);
			awsIot.deletePolicy(deletePolicyRequest);

			//delete thing
			DeleteThingRequest deleteThingRequest = new DeleteThingRequest();
			deleteThingRequest.setThingName(sn);
			awsIot.deleteThing(deleteThingRequest);

			//delete shadow
			DeleteThingShadowRequest deleteThingShadowRequest = new DeleteThingShadowRequest();
			deleteThingShadowRequest.setThingName(sn);
			deleteThingShadowRequest.setShadowName(sn);
			awsIotData.deleteThingShadow(deleteThingShadowRequest);
		}
		//device unbind company and clear certificate  for DB
		deviceDo.setCompanyId("");
		deviceDo.setCompanyCode("");
		deviceDo.setDevCertificate("");
		deviceRepository.save(deviceDo);

		return BasicUtil.prepareResponseObject(ResponseCode.DMSI0000,null);
	}
}
