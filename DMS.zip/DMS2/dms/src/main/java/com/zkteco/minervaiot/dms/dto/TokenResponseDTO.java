package com.zkteco.minervaiot.dms.dto;

import lombok.Data;

@Data
public class TokenResponseDTO {
	private String id;
	private String firstName;
	private String lastName;
	private String user_name;
	private String email;
	private String phone;
	private boolean verified;
	private boolean active;
	private String roleId;
	private String roleCode;
	private String roleName;
	private String lastLoginCompanyId;
	private String companyId;
	private String companyName;
	private String companyCode;
	private String client_id;
	private String issuedAt;
	private int exp;
	private String jti;
	private String code;
	private String message;
	private Object data;
	
	
}
