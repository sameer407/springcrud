package com.zkteco.minervaiot.dms.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class BioData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int no;
	
	private int index;
	
	private int valid;
	
	private int duress;
	
	private int type;
	
	private int majorVer;
	
	private int minorVer;
	
	private String fmt;
	
	private String tmp;
	
	
}
