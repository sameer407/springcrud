package com.zkteco.minervaiot.dms.dto;

import lombok.Data;

@Data
public class Command {
    private String companyId;
    private String siteId;
    private String sn;

    private CommandPayload payload;


    public Command() {  }

    public Command(String companyId, String siteId, String sn) {
        this.companyId = companyId;
        this.siteId = siteId;
        this.sn = sn;
    }
}
