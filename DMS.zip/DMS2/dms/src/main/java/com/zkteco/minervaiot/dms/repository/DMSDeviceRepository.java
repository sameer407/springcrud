package com.zkteco.minervaiot.dms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.zkteco.minervaiot.dms.dataobject.DMSDeviceDO;
@Repository
public interface DMSDeviceRepository extends JpaRepository<DMSDeviceDO, String> {

	DMSDeviceDO findBySn(String sn);

	List<DMSDeviceDO> findBySnIn(List<String> childSnList);

//	@Query("select ad from DBSDeviceDO ad where ad.commType=1 or ad.commType=2")
//	List<DMSDeviceDO> findPullList();

	DMSDeviceDO getById(String id);

}
