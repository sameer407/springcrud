package com.zkteco.minervaiot.dms.constants;

public class CommandTypeConstants {

    public static String DELETE_DEVICE = "system.delete.device";
}
