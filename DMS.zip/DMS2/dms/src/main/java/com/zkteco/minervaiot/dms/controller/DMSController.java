package com.zkteco.minervaiot.dms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zkteco.minervaiot.dms.dataobject.DMSDeviceDO;
import com.zkteco.minervaiot.dms.repository.DMSDeviceRepository;

import io.swagger.annotations.ApiOperation;

@CrossOrigin(origins = "http://localhost:3000/")
@Controller
@RestController

//@CrossOrigin(origins = "*")
@RequestMapping("/api/v1")
public class DMSController {

	@Autowired
	private DMSDeviceRepository dbsDeviceRepository;

//	@GetMapping("/")
//	public String index(Model modelView) {
//		List<DMSDeviceDO> dbsDevice;
//		dbsDevice = dbsDeviceRepository.findAll();
//		modelView.addAttribute("listDevice", dbsDevice);
//		return "index";
//	}

	
	// list of devices
	@GetMapping("/all")
	@ApiOperation(value = "Get Device data")
	
	public List<DMSDeviceDO> getAllDevices()
	{
		return	dbsDeviceRepository.findAll();
	 
	}
	
	
}
