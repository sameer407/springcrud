package com.zkteco.minervaiot.dms.service;

import org.springframework.http.ResponseEntity;

import com.zkteco.minervaiot.dms.util.ResultEntity;

public interface DMSOperationService {
	
	public ResponseEntity<ResultEntity> addDevice(String jsonStr);
	
	public ResponseEntity<ResultEntity> modifyDevice(String jsonStr);
	
	public ResponseEntity<ResultEntity> deleteDevice(String jsonStr);
	
	public ResponseEntity<ResultEntity> queryDeviceInfo(String jsonStr);
	
	public ResponseEntity<ResultEntity> enableDevice(String jsonStr);
	
	public ResponseEntity<ResultEntity> disableDevice(String jsonStr);
	
	public ResponseEntity<ResultEntity> rebootDevice(String jsonStr);
	
	public ResponseEntity<ResultEntity> uploadAttRecord(String jsonStr);
	
	public ResponseEntity<ResultEntity> uploadPersonRecord(String jsonStr);
	
	public ResponseEntity<ResultEntity> registerBiometrics(String jsonStr);
	
	public ResponseEntity<ResultEntity> cancelBiometrics(String jsonStr);
	
	public ResponseEntity<ResultEntity> queryDeviceCommand(String jsonStr);
}
