package com.zkteco.minervaiot.dms.config.security;

public class SecurityConstant {

	public static final String SCOPE_READ = "READ";

	public static final String SCOPE_WRITE = "WRITE";

	public static final String AUTHORIZATION = "Authorization";

	public static final String JWT = "JWT";

	public static final String BASIC = "Basic ";

	public static final String BEARER = "Bearer ";

	public static final String HEADER = "header";

	public static final String AUTHORIZATION_TYPE = "Oauth2";

}
