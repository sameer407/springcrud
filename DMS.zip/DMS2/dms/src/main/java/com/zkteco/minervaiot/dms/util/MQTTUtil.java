package com.zkteco.minervaiot.dms.util;

import com.zkteco.minervaiot.dms.constants.MQTTConstants;
import com.zkteco.minervaiot.dms.constants.ParamsConstants;
import com.zkteco.minervaiot.dms.dto.TokenResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.text.MessageFormat;
import java.util.Objects;


public class MQTTUtil {

    /****
     *  get Topic path with companId、siteId、sn
     *
     * @param companyId
     * @param siteId
     * @param sn
     * @return java.lang.String
     * @throws
     * @author howard.liu
     * @date 2021/12/15 16:05
     * @since 1.0.0
     */
    public static  String getTopic(String companyId, String siteId, String sn){
        return MessageFormat.format(MQTTConstants.TOPIC_PUBLISH_FORMAT,companyId,siteId,sn);
    }
}
