package com.zkteco.minervaiot.dms.service;

import com.zkteco.minervaiot.dms.dto.Command;

public interface CmdService {
	/****
	 * send delete device message to device
	 *
	 * @return void
	 * @throws
	 * @author howard.liu
	 * @date 2021/12/15 16:10
	 * @since 1.0.0
	 */
	 void issueDeleteDeviceCommand(Command command);
}
