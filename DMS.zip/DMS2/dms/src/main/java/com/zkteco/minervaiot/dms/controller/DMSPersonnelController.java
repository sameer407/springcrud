// package com.zkteco.minervaiot.dms.controller;
//
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.http.ResponseEntity;
// import org.springframework.web.bind.annotation.PostMapping;
// import org.springframework.web.bind.annotation.RequestBody;
// import org.springframework.web.bind.annotation.RequestMapping;
// import org.springframework.web.bind.annotation.RestController;
//
// import com.zkteco.minervaiot.dms.service.DMSPersonnelService;
// import com.zkteco.minervaiot.dms.util.ResultEntity;
//
// @RestController
// @RequestMapping(value = "/api/personnel-mgn")
// public class DMSPersonnelController {
//
// @Autowired
// private DMSPersonnelService dbsPersonnalService;
//
// @PostMapping(value = "syncPersonnel")
// public ResponseEntity<ResultEntity> syncPersonnal(@RequestBody String
// jsonStr) {
// ResultEntity result = new ResultEntity();
// ResponseEntity<ResultEntity> requestEntity =
// dbsPersonnalService.syncPersonnel(jsonStr);
// return requestEntity;
// }
//
// @PostMapping(value = "batchSyncPersonnelInformation")
// public ResponseEntity<ResultEntity> batchPersonnal(@RequestBody String
// jsonStr) {
// ResultEntity result = new ResultEntity();
// ResponseEntity<ResultEntity> requestEntity =
// dbsPersonnalService.batchSyncPersonnelInformation(jsonStr);
// return requestEntity;
// }
//
// @PostMapping(value = "removePersonnel")
// public ResponseEntity<ResultEntity> removePersonnal(@RequestBody String
// jsonStr) {
// ResultEntity result = new ResultEntity();
// ResponseEntity<ResultEntity> requestEntity =
// dbsPersonnalService.removePersonnel(jsonStr);
// return requestEntity;
// }
//
// @PostMapping(value = "removeBatchPersonnel")
// public ResponseEntity<ResultEntity> removeBatchPersonnal(@RequestBody String
// jsonStr) {
// ResultEntity result = new ResultEntity();
// ResponseEntity<ResultEntity> requestEntity =
// dbsPersonnalService.removeBatchPersonnel(jsonStr);
// return requestEntity;
// }
//
// @PostMapping(value = "syncPersonnelFacePhoto")
// public ResponseEntity<ResultEntity> syncPersonnalFacePhoto(@RequestBody
// String jsonStr) {
// ResultEntity result = new ResultEntity();
// ResponseEntity<ResultEntity> requestEntity =
// dbsPersonnalService.syncPersonnelFacePhoto(jsonStr);
// return requestEntity;
// }
//
// @PostMapping(value = "removeBiometricTemplate")
// public ResponseEntity<ResultEntity> removeBiometricTemplate(@RequestBody
// String jsonStr) {
// ResultEntity result = new ResultEntity();
// ResponseEntity<ResultEntity> requestEntity =
// dbsPersonnalService.removeBiometricTemplate(jsonStr);
// return requestEntity;
// }
// }
