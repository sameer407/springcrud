package com.zkteco.minervaiot.dms.util;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel
public class Result {
//
	@ApiModelProperty(name = "code", dataType = "String", example = "DMSI0000", value = "The service code for the specific request.", position = 1)
	private String code;
	@ApiModelProperty(name = "message", dataType = "String", example = "Success", value = "The message for the specific code.", position = 2)
	private String message;
	@ApiModelProperty(name = "data", value = "This will contain the response object for the called API.", example = "{}", position = 3)
	private Object data;

}
