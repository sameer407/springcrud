package com.zkteco.minervaiot.dms.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import com.zkteco.minervaiot.dms.dto.DeviceDeleteDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import com.zkteco.minervaiot.dms.dto.DeviceDTO;
import com.zkteco.minervaiot.dms.service.DeviceService;
import com.zkteco.minervaiot.dms.util.Result;

@ExtendWith(MockitoExtension.class)
class DeviceControllerTest {

	@InjectMocks
	DeviceController deviceController;

	@Mock
	DeviceService deviceService;

	Result result = null;
	DeviceDTO deviceDTO = null;
	List<DeviceDTO> deviceDTOList = null;

	DeviceDeleteDTO deviceDeleteDTO=null;

	@BeforeEach
	public void init() {

		deviceDTO = new DeviceDTO();
		deviceDTO.setId("1");
		deviceDTO.setSn("11");

		deviceDTOList = new ArrayList<>();
		deviceDTOList.add(deviceDTO);

		deviceDeleteDTO = new DeviceDeleteDTO();
		deviceDeleteDTO.setSiteId("12");
	}

	@Test
	void testGenerateSecretNumbe() {
		String sn = "1";
		Mockito.when(deviceService.saveDeviceSecretNo(sn)).thenReturn(result);
		ResponseEntity<Result> result = deviceController.generateSecretNumbe(sn);
		assertNotNull(result);
	}

	@Test
	void testGetSecretNumbe() {
		String sn = "1";
		Mockito.when(deviceService.getDeviceSecretNo(sn)).thenReturn(result);
		ResponseEntity<Result> result = deviceController.getSecretNumbe(sn);
		assertNotNull(result);
	}

	@Test
	void testUpdateDevice() {
		String sn = "1";
		Mockito.when(deviceService.updateDevices(sn, deviceDTO)).thenReturn(result);
		ResponseEntity<Result> result = deviceController.updateDevice(sn, deviceDTO);
		assertNotNull(result);
	}

	@Test
	void testDeviceSearch() {
		int pageNumber = 1;
		int pageSize = 10;
		String deviceSn = "001";
		String mac = "2222";
		String productCode = "45TT";
		String deviceAlias = "p";

		Mockito.when(deviceService.findByfilter(pageNumber, pageSize, deviceSn, mac, productCode, deviceAlias)).thenReturn(result);
		ResponseEntity<Result> result = deviceController.deviceSearch(pageNumber, pageSize, deviceSn, mac, productCode, deviceAlias);
		assertNotNull(result);
	}

	@Test
	void testCreateDevice() {
		Mockito.when(deviceService.addOrUpdateDevice(deviceDTOList)).thenReturn(result);
		ResponseEntity<Result> result = deviceController.createDevice(deviceDTOList);
		assertNotNull(result);
	}

	@Test
	void getDeviceBindCompany() {
		String sn = "1";
		ResponseEntity<Result> result = deviceController.getDeviceBindCompany(sn);
		System.out.println(result);
		assertNotNull(result);
	}

	@Test
	void testDeleteDevice() {
		String sn = "1";
		ResponseEntity<Result> result = deviceController.deleteDevice(sn,deviceDeleteDTO);
		System.out.println(result);
		assertNotNull(result);
	}


}
