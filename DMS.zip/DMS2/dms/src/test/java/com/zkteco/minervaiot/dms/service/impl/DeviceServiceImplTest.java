package com.zkteco.minervaiot.dms.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.zkteco.minervaiot.dms.config.MessageConfig;
import com.zkteco.minervaiot.dms.dataobject.DeviceDO;
import com.zkteco.minervaiot.dms.dto.DeviceDTO;
import com.zkteco.minervaiot.dms.repository.DeviceRepository;
import com.zkteco.minervaiot.dms.repository.DeviceSecretnoRepository;
import com.zkteco.minervaiot.dms.service.DeviceSecretnoDO;
import com.zkteco.minervaiot.dms.util.BasicUtil;
import com.zkteco.minervaiot.dms.util.CommonSpec;
import com.zkteco.minervaiot.dms.util.Result;

@ExtendWith(MockitoExtension.class)
class DeviceServiceImplTest {

	@InjectMocks
	DeviceServiceImpl deviceServiceImpl;

	@Mock
	DeviceRepository deviceRepository;

	@Mock
	DeviceSecretnoRepository secretnoRepository;

	@Mock
	BasicUtil basicUtil;

	@Mock
	MessageConfig messageConfig;

	@Mock
	CommonSpec commonSpec;

	@Mock
	Page<DeviceDO> deviceDOPage;

	@Mock
	Pageable paging;

	@Mock
	PageRequest pageRequest;

	DeviceSecretnoDO secretnumberDO = null;
	DeviceDTO deviceDTO = null;
	DeviceDO deviceDO = null;
	List<DeviceDTO> deviceDTOList = null;

	@BeforeEach
	public void init() {

		secretnumberDO = new DeviceSecretnoDO();
		secretnumberDO.setId("1");

		deviceDTO = new DeviceDTO();
		deviceDTO.setSn("1");

		deviceDOPage = new Page<DeviceDO>() {

			@Override
			public Iterator<DeviceDO> iterator() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Pageable previousPageable() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Pageable nextPageable() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public boolean isLast() {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean isFirst() {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean hasPrevious() {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean hasNext() {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean hasContent() {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public Sort getSort() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public int getSize() {
				// TODO Auto-generated method stub
				return 0;
			}

			@Override
			public int getNumberOfElements() {
				// TODO Auto-generated method stub
				return 0;
			}

			@Override
			public int getNumber() {
				// TODO Auto-generated method stub
				return 0;
			}

			@Override
			public List<DeviceDO> getContent() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public <U> Page<U> map(Function<? super DeviceDO, ? extends U> converter) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public int getTotalPages() {
				// TODO Auto-generated method stub
				return 0;
			}

			@Override
			public long getTotalElements() {
				// TODO Auto-generated method stub
				return 0;
			}
		};
	}

	@Test
	void testGetDeviceSecretNoWhenDeviceSnIsEmpty() {
		String deviceSnr = "";
		Result result = deviceServiceImpl.getDeviceSecretNo(deviceSnr);
		assertEquals("DMSE0001", result.getCode());
	}

	@Test
	void testGetDeviceSecretNoWhenDeviceSnIsNotEmptyAndSecretnumberDOIsEmpty() {
		String deviceSn = "1";
		secretnumberDO = new DeviceSecretnoDO();
		Mockito.when(secretnoRepository.findBySn(deviceSn)).thenReturn(null);
		Result result = deviceServiceImpl.getDeviceSecretNo(deviceSn);
		assertEquals("DMSE0003", result.getCode());
	}

	@Test
	void testGetDeviceSecretNoWhenDeviceSnIsNotEmptyAndSecretnumberDOIsNotEmpty() {
		String deviceSn = "1";
		secretnumberDO = new DeviceSecretnoDO();
		secretnumberDO.setId("1");
		secretnumberDO.setSn("11");
		secretnumberDO.setSecretNo("111");
		Mockito.when(secretnoRepository.findBySn(deviceSn)).thenReturn(secretnumberDO);
		Result result = deviceServiceImpl.getDeviceSecretNo(deviceSn);
		assertEquals("DMSI0000", result.getCode());
	}

	@Test
	void testSaveDeviceSecretNo() {
		String deviceSn = "";
		Result result = deviceServiceImpl.saveDeviceSecretNo(deviceSn);
		assertEquals("DMSE0001", result.getCode());
	}

	@Test
	void testSaveDeviceSecretNoIsEmpty() {
		String deviceSn = "";
		Result result = deviceServiceImpl.saveDeviceSecretNo(deviceSn);
		assertEquals("DMSE0001", result.getCode());
	}

	@Test
	void testSaveDeviceSecretNoIsExist() {
		String deviceSn = "1";
		Mockito.when(secretnoRepository.existsBySn(deviceSn)).thenReturn(true);
		Result result = deviceServiceImpl.saveDeviceSecretNo(deviceSn);
		assertEquals("DMSE0002", result.getCode());
	}

	@Test
	void testSaveDeviceSecretNoIsNotExist() {
		String deviceSn = "1";
		Mockito.when(secretnoRepository.existsBySn(deviceSn)).thenReturn(false);
		Result result = deviceServiceImpl.saveDeviceSecretNo(deviceSn);
		assertEquals("DMSI0003", result.getCode());
	}

	@Test
	void testupdateDevicesWhenSnAndDeviceDTOIsNull() {
		String sn = "";
		Mockito.when(deviceRepository.findBySn(sn)).thenReturn(null);
		Result result = deviceServiceImpl.updateDevices(sn, deviceDTO);
		assertEquals("DMSE0003", result.getCode());
	}

	@Test
	void testupdateDevicesWhenSnAndDeviceDTOIsNotNull() {
		String sn = "1";
		deviceDO = new DeviceDO();
		deviceDO.setId("1");
		deviceDTO = new DeviceDTO();
		deviceDTO.setSn("1");
		Mockito.when(deviceRepository.findBySn(sn)).thenReturn(deviceDO);
		Mockito.when(deviceRepository.findBySnIgnoreCaseAndIdNot(deviceDTO.getSn(), deviceDO.getId())).thenReturn(deviceDO);
		Result result = deviceServiceImpl.updateDevices(sn, deviceDTO);
		assertEquals("DMSE0002", result.getCode());
	}

	@Test
	void testupdateDevicesWhenduplicateSnIsNull() {
		String sn = "1";
		deviceDO = new DeviceDO();
		deviceDO.setId("1");
		deviceDTO = new DeviceDTO();
		deviceDTO.setSn("1");
		Mockito.when(deviceRepository.findBySn(sn)).thenReturn(deviceDO);
		Mockito.when(deviceRepository.findBySnIgnoreCaseAndIdNot(deviceDTO.getSn(), deviceDO.getId())).thenReturn(null);
		Result result = deviceServiceImpl.updateDevices(sn, deviceDTO);
		assertEquals("DMSI0002", result.getCode());
	}

	@Test
	void testAddOrUpdateDevice1() {
		deviceDTOList = new ArrayList<>();
		deviceDTOList.add(deviceDTO);
		Mockito.when(deviceRepository.findBySn(deviceDTO.getSn())).thenReturn(deviceDO);
		Result result = deviceServiceImpl.addOrUpdateDevice(deviceDTOList);
		assertEquals("DMSI0000", result.getCode());
	}

	@Test
	void testAddOrUpdateDevice2() {
		deviceDTOList = new ArrayList<>();
		deviceDTOList.add(deviceDTO);

		deviceDO = new DeviceDO();
		deviceDO.setId("1");
		Mockito.when(deviceRepository.findBySn(deviceDTO.getSn())).thenReturn(deviceDO);
		Result result = deviceServiceImpl.addOrUpdateDevice(deviceDTOList);
		assertEquals("DMSI0000", result.getCode());
	}

	@Test
	void testAddOrUpdateDeviceWhenPhotoURLIsWrong() {
		deviceDTO = new DeviceDTO();
		deviceDTO.setSn("1");
		deviceDTO.setPhoto("hh");
		deviceDTOList = new ArrayList<>();
		deviceDTOList.add(deviceDTO);

		deviceDO = new DeviceDO();
		deviceDO.setId("1");
		Mockito.when(deviceRepository.findBySn(deviceDTO.getSn())).thenReturn(deviceDO);
		Result result = deviceServiceImpl.addOrUpdateDevice(deviceDTOList);
		assertEquals("DMSW0000", result.getCode());
	}

	int pageNumber = 1;
	int pageSize = 10;
	String deviceSn = "001";
	String mac = "2222";
	String productCode = "45TT";
	String deviceAlias = "p";

	// @Test
	// void testFindByfilter() {
	// int pageNumber = 1;
	// int pageSize = 10;
	// String deviceSn = "001";
	// String mac = "2222";
	// String productCode = "45TT";
	// String deviceAlias = "p";
	//
	// // PageRequest paging =null;
	//
	// // Mockito.when(PageRequest.of(pageNumber - 1,
	// // pageSize)).thenReturn(pageRequest);
	// Mockito.when(deviceRepository.findAll(commonSpec.getDEviceFilter(deviceSn,
	// mac, productCode, deviceAlias), paging))
	// .thenReturn(deviceDOPage);
	// Result result = deviceServiceImpl.findByfilter(pageNumber, pageSize,
	// deviceSn, mac, productCode, deviceAlias);
	// assertEquals("DMSE0004", result.getCode());
	// }


	@Test
	void getDeviceBindCompany() {
		String sn = "1";
		Result result = deviceServiceImpl.getDeviceBindCompany(sn);
		assertEquals("DMSE0003", result.getCode());
	}

}
